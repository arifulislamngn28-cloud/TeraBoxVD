'use strict';
/**
 * TeraBeam server — zero external dependencies.
 *
 * Run:  node server/index.js
 * Env:  PORT, SITE_URL, APP_SECRET, TERABOX_ACCESS_TOKEN, TERABOX_COOKIE,
 *       DOWNLOAD_MODE, RATE_LIMIT, AUTO_APPROVE_KEYS
 */
const http = require('http');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { URL } = require('url');
const { Readable } = require('stream');

const config = require('../site.config');
const tb = require('./terabox');
const { encrypt, decrypt } = require('./tokens');
const keys = require('./keys');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const PORT = config.runtime.port;
const SECRET = config.runtime.secret;
const RATE_WINDOW_MS = 10 * 60 * 1000;

const ACCESS_TOKEN = process.env.TERABOX_ACCESS_TOKEN || '';
const TERABOX_COOKIE = process.env.TERABOX_COOKIE || '';

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        try {
          resolve(Object.fromEntries(new URLSearchParams(raw)));
        } catch {
          reject(new Error('Invalid JSON body'));
        }
      }
    });
    req.on('error', reject);
  });
}

/** Sliding-window rate limiter, keyed by IP. */
const buckets = new Map();
function rateLimit(ip) {
  const now = Date.now();
  const bucket = buckets.get(ip) || { count: 0, reset: now + RATE_WINDOW_MS };
  if (now > bucket.reset) {
    bucket.count = 0;
    bucket.reset = now + RATE_WINDOW_MS;
  }
  bucket.count += 1;
  buckets.set(ip, bucket);
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (now > v.reset) buckets.delete(k);
  }
  return bucket.count <= config.runtime.rateLimit;
}

/** fetch with a generous timeout and one retry (TeraBox CDNs are flaky). */
async function fetchRobust(url, options = {}, attempts = 2) {
  let lastError = null;
  for (let i = 0; i < attempts; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), options.timeout || 30000);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal, redirect: 'follow' });
      clearTimeout(timer);
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      await new Promise((r) => setTimeout(r, 800 * (i + 1)));
    }
  }
  throw lastError || new Error('upstream fetch failed');
}

/** Public base URL of this deployment (works behind a proxy too). */
function baseUrl(req) {
  const proto = (req.headers['x-forwarded-proto'] || '').split(',')[0].trim() || 'http';
  const host = (req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}` : config.brand.url;
}

/** Query parameters of a plain Node request (no Express). */
function queryOf(req) {
  const idx = req.url.indexOf('?');
  return new URLSearchParams(idx >= 0 ? req.url.slice(idx + 1) : '');
}

function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return String(fwd).split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}

/* ------------------------------------------------------------------ */
/* static file serving                                                 */
/* ------------------------------------------------------------------ */

async function serveStatic(req, res, pathname) {
  const rel = decodeURIComponent(pathname);
  const clean = rel.replace(/^\/+/, '').replace(/\/+$/, '');

  // Try, in order: path + .html, path/index.html, the raw path
  const candidates = clean
    ? [`${clean}.html`, `${clean}/index.html`, clean]
    : ['index.html'];

  let target = null;
  let stat = null;
  for (const candidate of candidates) {
    const full = path.join(PUBLIC_DIR, path.normalize(candidate).replace(/^(\.\.[/\\])+/, ''));
    if (!full.startsWith(PUBLIC_DIR)) continue;
    try {
      const s = await fsp.stat(full);
      if (s.isFile()) {
        target = full;
        stat = s;
        break;
      }
    } catch {
      /* next candidate */
    }
  }

  try {
    if (!target) throw new Error('not found');

    const ext = path.extname(target).toLowerCase();
    const isHtml = ext === '.html';

    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': isHtml ? 'no-cache' : 'public, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
    });
    fs.createReadStream(target).pipe(res);
  } catch {
    const notFound = path.join(PUBLIC_DIR, '404.html');
    try {
      const body = await fsp.readFile(notFound);
      res.writeHead(404, { 'Content-Type': MIME['.html'], 'Content-Length': body.length });
      res.end(body);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 — Not found');
    }
  }
}

/* ------------------------------------------------------------------ */
/* tokens                                                              */
/* ------------------------------------------------------------------ */

function makeToken(payload) {
  return encrypt({ ...payload, e: Date.now() + 1000 * 60 * 60 * 2 }, SECRET);
}

function readToken(req, res) {
  const token = queryOf(req).get('t') || req.headers['x-download-token'] || '';
  const payload = decrypt(String(token), SECRET);
  if (!payload) {
    sendJson(res, 400, {
      ok: false,
      error: 'This link has expired. Please run the search again.',
    });
    return null;
  }
  return payload;
}

/* ------------------------------------------------------------------ */
/* API — resolve a share link                                          */
/* ------------------------------------------------------------------ */

async function handleResolve(req, res) {
  const ip = clientIp(req);
  if (!rateLimit(ip)) {
    sendJson(res, 429, {
      ok: false,
      error: 'Too many requests. Please wait a few minutes and try again.',
    });
    return;
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    sendJson(res, 400, { ok: false, error: err.message });
    return;
  }

  const url = String(body.url || '').trim();
  const pwd = String(body.pwd || '').trim();
  const dir = String(body.dir || '').trim();

  if (!url) {
    sendJson(res, 400, { ok: false, error: 'Paste a TeraBox share link first.' });
    return;
  }

  const started = Date.now();
  try {
    const result = await tb.resolveShare({
      url,
      pwd,
      dir,
      accessToken: ACCESS_TOKEN,
      cookie: TERABOX_COOKIE,
    });

    const files = result.files.map((file) => {
      const streamToken = file.isDir
        ? ''
        : makeToken({
            k: 'stream',
            h: result.host,
            c: result.code,
            u: String(result.uk),
            s: String(result.shareid),
            f: file.fsId,
            n: file.name,
          });
      const fileToken = file.dlink
        ? makeToken({
            k: 'file',
            d: file.dlink,
            c: TERABOX_COOKIE,
            n: file.name,
            s: file.size,
          })
        : '';

      return {
        fsId: file.fsId,
        name: file.name,
        size: file.size,
        sizeText: file.sizeText,
        isDir: file.isDir,
        path: file.path,
        category: file.category,
        md5: file.md5,
        thumb: file.thumb,
        hasDirect: !!file.dlink,
        streamUrl: file.category === 'video' && streamToken ? `/api/stream?t=${encodeURIComponent(streamToken)}` : '',
        downloadUrl: fileToken ? `/api/file?t=${encodeURIComponent(fileToken)}&mode=download` : '',
        openUrl: `https://${result.host}/s/${result.code}`,
      };
    });

    const totalSize = files.reduce((sum, f) => sum + (f.size || 0), 0);

    sendJson(res, 200, {
      ok: true,
      ms: Date.now() - started,
      canDownload: result.canDownload,
      share: {
        title: result.title,
        owner: result.shareUser,
        country: result.country,
        host: result.host,
        dir: result.dir,
        fileCount: files.length,
        totalSize,
        totalSizeText: tb.humanSize(totalSize),
        shareUrl: result.shareUrl,
      },
      files,
    });
  } catch (err) {
    const status = err instanceof tb.ResolveError ? 400 : 500;
    sendJson(res, status, {
      ok: false,
      code: err.code || 'ERROR',
      error: err.message || 'Something went wrong while reading that link.',
    });
  }
}

/* ------------------------------------------------------------------ */
/* API — HLS playlist (segments rewritten to our own proxy)             */
/* ------------------------------------------------------------------ */

async function handleStream(req, res) {
  const payload = readToken(req, res);
  if (!payload || payload.k !== 'stream') return;

  try {
    const session = new tb.Session(payload.h);
    await session.bootstrap(payload.c);

    const { playlist } = await tb.fetchPlaylist(session, {
      uk: payload.u,
      shareid: payload.s,
      fsId: payload.f,
      type: 'M3U8_AUTO_480',
    });

    // Rewrite every segment/key URI so the browser talks to us only.
    const origin = baseUrl(req);
    const rewritten = playlist.replace(/^(https?:\/\/\S+)$/gm, (url) => {
      const t = makeToken({ k: 'seg', u: url });
      return `${origin}/api/segment?t=${encodeURIComponent(t)}`;
    });

    res.writeHead(200, {
      'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8',
      'Content-Length': Buffer.byteLength(rewritten),
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
    });
    res.end(rewritten);
  } catch (err) {
    sendJson(res, 502, {
      ok: false,
      error: err.message || 'Could not prepare the stream. You can still download the file.',
    });
  }
}

/* ------------------------------------------------------------------ */
/* API — segment proxy                                                  */
/* ------------------------------------------------------------------ */

async function handleSegment(req, res) {
  const payload = readToken(req, res);
  if (!payload || payload.k !== 'seg') return;

  try {
    const upstream = await fetchRobust(payload.u, {
      headers: {
        'User-Agent': tb.DEFAULT_UA,
        Referer: 'https://www.terabox.com/',
        ...(req.headers.range ? { Range: req.headers.range } : {}),
      },
    });

    const headers = {
      'Content-Type': upstream.headers.get('content-type') || 'video/mp2t',
      'Cache-Control': 'public, max-age=3600',
      'Access-Control-Allow-Origin': '*',
      'Accept-Ranges': 'bytes',
    };
    const len = upstream.headers.get('content-length');
    if (len) headers['Content-Length'] = len;
    const cr = upstream.headers.get('content-range');
    if (cr) headers['Content-Range'] = cr;

    res.writeHead(upstream.status, headers);
    const body = Readable.fromWeb(upstream.body);
    body.on('error', () => res.destroy());
    res.on('close', () => body.destroy());
    body.pipe(res);
  } catch {
    if (!res.headersSent) sendJson(res, 502, { ok: false, error: 'Segment unavailable.' });
    else res.destroy();
  }
}

/* ------------------------------------------------------------------ */
/* API — direct download                                                */
/* ------------------------------------------------------------------ */

async function handleFile(req, res) {
  const payload = readToken(req, res);
  if (!payload || payload.k !== 'file') return;

  const mode = String(queryOf(req).get('mode') || 'download');

  try {
    const upstream = await fetchRobust(payload.d, {
      headers: {
        'User-Agent': tb.DEFAULT_UA,
        Referer: 'https://www.terabox.com/',
        ...(payload.c ? { Cookie: payload.c } : {}),
        ...(req.headers.range ? { Range: req.headers.range } : {}),
      },
    });

    const headers = {
      'Content-Type': upstream.headers.get('content-type') || 'application/octet-stream',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'private, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
    };
    const len = upstream.headers.get('content-length');
    if (len) headers['Content-Length'] = len;
    const cr = upstream.headers.get('content-range');
    if (cr) headers['Content-Range'] = cr;
    const disposition = mode === 'download' ? 'attachment' : 'inline';
    headers['Content-Disposition'] = `${disposition}; filename="${encodeURIComponent(payload.n || 'file')}"`;

    res.writeHead(upstream.status, headers);
    const body = Readable.fromWeb(upstream.body);
    body.on('error', () => res.destroy());
    res.on('close', () => body.destroy());
    body.pipe(res);
  } catch {
    if (!res.headersSent) {
      sendJson(res, 502, { ok: false, error: 'Could not fetch the file from TeraBox. Please try again.' });
    } else {
      res.destroy();
    }
  }
}

/* ------------------------------------------------------------------ */
/* Developer API (/v1/api)                                             */
/* ------------------------------------------------------------------ */

async function handleV1(req, res) {
  const apiKey = req.headers['x-api-key'] || queryOf(req).get('api_key') || '';
  const entry = keys.findKey(apiKey);
  if (!entry) {
    sendJson(res, 401, {
      ok: false,
      error: 'Invalid or missing API key. Send it in the X-API-Key header.',
    });
    return;
  }
  if (entry.used >= entry.quota) {
    sendJson(res, 429, { ok: false, error: 'Quota exceeded for this API key.' });
    return;
  }

  let body = {};
  if (req.method === 'POST') {
    try {
      body = await readBody(req);
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
      return;
    }
  }
  const q = new URL(req.url, 'http://localhost');
  const url = String(body.url || q.searchParams.get('url') || '').trim();
  const pwd = String(body.pwd || q.searchParams.get('pwd') || '').trim();
  const dir = String(body.dir_path || q.searchParams.get('dir_path') || '').trim();
  const page = Number(body.page || q.searchParams.get('page') || 1);

  if (!url) {
    sendJson(res, 400, { ok: false, error: 'Missing "url" parameter.' });
    return;
  }

  try {
    const result = await tb.resolveShare({
      url,
      pwd,
      dir,
      page,
      accessToken: ACCESS_TOKEN,
      cookie: TERABOX_COOKIE,
    });
    keys.countUsage(entry.id);

    sendJson(res, 200, {
      ok: true,
      share: {
        title: result.title,
        owner: result.shareUser,
        country: result.country,
        dir: result.dir,
        fileCount: result.files.length,
        share_url: result.shareUrl,
      },
      files: result.files.map((f) => ({
        fs_id: f.fsId,
        filename: f.name,
        size: f.size,
        size_readable: f.sizeText,
        is_dir: f.isDir,
        path: f.path,
        category: f.category,
        md5: f.md5,
        download_url: f.dlink || '',
        stream_url:
          f.category === 'video'
            ? `${config.brand.url}/api/stream?t=${encodeURIComponent(
                makeToken({ k: 'stream', h: result.host, c: result.code, u: String(result.uk), s: String(result.shareid), f: f.fsId, n: f.name })
              )}`
            : '',
      })),
      usage: { used: entry.used + 1, quota: entry.quota },
    });
  } catch (err) {
    sendJson(res, err instanceof tb.ResolveError ? 400 : 500, {
      ok: false,
      code: err.code || 'ERROR',
      error: err.message,
    });
  }
}

/* ------------------------------------------------------------------ */
/* API — request a key                                                  */
/* ------------------------------------------------------------------ */

async function handleKeyRequest(req, res) {
  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    sendJson(res, 400, { ok: false, error: err.message });
    return;
  }
  const email = String(body.email || '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    sendJson(res, 400, { ok: false, error: 'Please enter a valid email address.' });
    return;
  }
  const existing = keys.listKeys().find((k) => k.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    sendJson(res, 200, {
      ok: true,
      message: 'You already have a key with this email. Check your inbox or contact support.',
      key: existing.active ? existing.key : undefined,
      status: existing.active ? 'active' : 'pending',
    });
    return;
  }
  const entry = keys.createKey({
    email,
    plan: 'free',
    autoApprove: config.runtime.autoApproveKeys,
  });
  sendJson(res, 200, {
    ok: true,
    status: entry.active ? 'active' : 'pending',
    key: entry.active ? entry.key : undefined,
    message: entry.active
      ? 'Your API key is ready. Copy it now — we also email it to you.'
      : 'Thanks! Your key is pending review and will arrive by email shortly.',
  });
}

/* ------------------------------------------------------------------ */
/* router                                                              */
/* ------------------------------------------------------------------ */

async function route(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = url.pathname;

  if (p === '/api/resolve' && req.method === 'POST') return handleResolve(req, res);
  if (p === '/api/stream') return handleStream(req, res);
  if (p === '/api/segment') return handleSegment(req, res);
  if (p === '/api/file') return handleFile(req, res);
  if (p === '/api/keys/request' && req.method === 'POST') return handleKeyRequest(req, res);
  if (p === '/v1/api') return handleV1(req, res);
  if (p === '/healthz') {
    return sendJson(res, 200, {
      ok: true,
      uptime: Math.round(process.uptime()),
      downloadsEnabled: !!(ACCESS_TOKEN || TERABOX_COOKIE),
    });
  }

  if (p === '/robots.txt') {
    const body = `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /v1/\nSitemap: ${config.brand.url}/sitemap.xml\n`;
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end(body);
  }
  if (p === '/sitemap.xml') {
    const pages = ['', 'about', 'faq', 'supported-domains', 'api', 'contact', 'privacy-policy', 'terms'];
    const urls = pages
      .map((slug) => `  <url><loc>${config.brand.url}/${slug ? `${slug}/` : ''}</loc></url>`)
      .join('\n');
    const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
    res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8' });
    return res.end(body);
  }

  return serveStatic(req, res, p);
}

const server = http.createServer((req, res) => {
  route(req, res).catch((err) => {
    console.error('[error]', err);
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: 'Internal server error' });
    else res.destroy();
  });
});

server.headersTimeout = 65000;
server.requestTimeout = 0;

server.listen(PORT, () => {
  console.log(`\n  ${config.brand.name} is running`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  → brand: ${config.brand.name} (${config.brand.domain})`);
  console.log(
    `  → direct downloads: ${ACCESS_TOKEN || TERABOX_COOKIE ? 'enabled' : 'disabled (no TERABOX_ACCESS_TOKEN / TERABOX_COOKIE)'}`
  );
  console.log('  → streaming + file listing: always available\n');
});

module.exports = server;
