'use strict';
/**
 * TeraBox share resolver — implements the flow the TeraBox web app itself
 * uses (reverse-engineered from terabox.com's own share bundle).
 *
 *   0. GET  /sharing/link?surl=CODE     -> session cookies + window.jsToken
 *   1. GET  /api/shorturlinfo          -> shareid, uk, sign, timestamp, file list
 *   2. POST /share/verify               -> only for extraction-code protected shares
 *   3. GET  /share/list                 -> contents of a sub-folder
 *   4. GET  /share/streaming            -> HLS playlist (anonymous, signed with HMAC-SHA1)
 *   5. GET  /share/download             -> direct CDN link (needs server credentials)
 *
 * Everything degrades gracefully: a dead mirror never breaks a request, and
 * every failure is translated into a message a human can act on.
 */

const crypto = require('crypto');

const DEFAULT_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

const APP_ID = '250528';
const CHANNEL = 'dubox';
const CLIENT_TYPE = '0';
const STREAM_SALT = 'iuuPc64E4Fhn0rTXEzrnbLph0o5qyEEa';

const FALLBACK_HOSTS = [
  'www.terabox.com',
  'terabox.app',
  '1024terabox.com',
  'teraboxapp.com',
  'teraboxlink.com',
  'teraboxshare.com',
  'terafileshare.com',
  '4funbox.com',
  'mirrobox.com',
  'nephobox.com',
  'freeterabox.com',
  '1024tera.com',
];

const ERRNO_MESSAGES = {
  '-2': 'The file could not be found. It may have been deleted.',
  '-4': 'This share has been blocked because of local law or TeraBox policy.',
  '-6': 'Please sign in to TeraBox and try again.',
  '-7': 'The share could not be opened. Please try again in a moment.',
  '-8': 'This share has been blocked because of local law or TeraBox policy.',
  '-9': 'This link is protected by an extraction code. Enter the 4-character code and try again.',
  '-12': 'This link is invalid or has expired. Ask the sender for a fresh link.',
  '-21': 'This share has expired.',
  '2': 'The link format is not recognised. Copy the whole link from the address bar.',
  '105': 'The link format is not recognised. Copy the whole link from the address bar.',
  '130': 'TeraBox could not prepare a preview for this file.',
};

class ResolveError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.name = 'ResolveError';
    this.code = code;
    this.extra = extra;
  }
}

/* ------------------------------------------------------------------ */
/* cookies                                                             */
/* ------------------------------------------------------------------ */

class CookieJar {
  constructor() {
    this.jar = new Map();
  }

  absorb(res) {
    const list = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const raw of list) {
      for (const part of String(raw).split(/,(?=\s*[^;=]+=)/)) {
        const kv = part.split(';')[0];
        const i = kv.indexOf('=');
        if (i < 0) continue;
        const name = kv.slice(0, i).trim();
        const value = kv.slice(i + 1).trim();
        if (!name) continue;
        this.jar.set(name, value);
      }
    }
    return this;
  }

  get(name) {
    return this.jar.get(name) || '';
  }

  header() {
    return [...this.jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }

  /** BDCLND / BOXCLND authorise the share download. */
  get shareKey() {
    return this.get('BDCLND') || this.get('BOXCLND') || '';
  }
}

/* ------------------------------------------------------------------ */
/* URL parsing                                                         */
/* ------------------------------------------------------------------ */

const KNOWN_HOSTS = new Set([
  'terabox.com', 'terabox.app', 'teraboxapp.com', '1024terabox.com', '1024tera.com',
  'freeterabox.com', 'teraboxlink.com', 'teraboxshare.com', 'terasharelink.com',
  'terasharefile.com', 'terafileshare.com', '4funbox.com', 'mirrobox.com', 'nephobox.com',
  'tibibox.com', 'xpanbox.com', 'terabox.my', 'qiwangbox.com', 'terapk.com', '1024box.com',
  'momerybox.com', 'gibibox.com', 'funpavo.com',
]);

/**
 * Pull the share code out of any TeraBox share URL shape:
 *   https://www.terabox.com/s/1AbCdEf...
 *   https://www.terabox.com/sharing/link?surl=AbCdEf...
 *   https://www.1024tera.com/chinese/sharing/link?surl=AbCdEf...
 *   ...or a bare code pasted on its own.
 */
function parseShareUrl(input) {
  const raw = String(input || '').trim();
  if (!raw) throw new ResolveError('EMPTY_INPUT', 'Paste a TeraBox share link to get started.');

  let candidate = raw;
  if (!/^https?:\/\//i.test(candidate)) {
    if (/^[A-Za-z0-9_-]{12,}$/.test(candidate)) {
      return { host: 'www.terabox.com', code: candidate, pwd: '', original: raw };
    }
    candidate = `https://${candidate.replace(/^\/+/, '')}`;
  }

  let u;
  try {
    u = new URL(candidate);
  } catch {
    throw new ResolveError(
      'BAD_URL',
      'That does not look like a valid link. Copy the whole link from your address bar.'
    );
  }

  const host = u.hostname.toLowerCase().replace(/^www\./, '');

  let code = null;
  const pathMatch = u.pathname.match(/\/s\/([A-Za-z0-9_-]{6,})/);
  if (pathMatch) code = pathMatch[1];

  if (!code) {
    const surl =
      u.searchParams.get('surl') ||
      u.searchParams.get('shareurl') ||
      (u.href.match(/[?&]surl=([A-Za-z0-9_-]+)/) || [])[1];
    if (surl) code = surl;
  }

  if (!code) {
    const loose = u.href.match(/\/s\/([A-Za-z0-9_-]{6,})/);
    if (loose) code = loose[1];
  }

  if (!code) {
    throw new ResolveError(
      'BAD_URL',
      'No share code found in that link. A TeraBox link looks like terabox.com/s/1AbCdEf…'
    );
  }

  const pwd = u.searchParams.get('pwd') || u.searchParams.get('password') || '';
  return { host, code, pwd, original: raw };
}

/** TeraBox addresses a share both as "1CODE" (shorturl) and "CODE" (surl). */
function codeCandidates(code) {
  const list = [code];
  if (code.startsWith('1') && code.length > 12) list.push(code.slice(1));
  if (!code.startsWith('1') && code.length > 10) list.push('1' + code);
  return [...new Set(list)];
}

/* ------------------------------------------------------------------ */
/* HTTP helpers                                                        */
/* ------------------------------------------------------------------ */

async function http(url, options = {}) {
  const { timeout = 15000, ...rest } = options;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...rest, signal: controller.signal, redirect: 'follow' });
  } finally {
    clearTimeout(timer);
  }
}

function baseHeaders(host, jar, extra = {}) {
  const headers = {
    'User-Agent': DEFAULT_UA,
    'X-Requested-With': 'XMLHttpRequest',
    Accept: 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    Referer: `https://${host}/`,
    Origin: `https://${host}`,
    ...extra,
  };
  const cookie = jar && jar.header();
  if (cookie) headers.Cookie = cookie;
  return headers;
}

async function readJson(res) {
  const text = await res.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Session: cookies + jsToken from the share page                      */
/* ------------------------------------------------------------------ */

class Session {
  constructor(host) {
    this.host = host;
    this.jar = new CookieJar();
    this.jsToken = '';
    this.pcftoken = '';
  }

  get browserid() {
    return this.jar.get('browserid');
  }

  /** Load the share page once: it carries the cookies and the JS token. */
  async bootstrap(code) {
    const url = `https://${this.host}/sharing/link?surl=${encodeURIComponent(code)}`;
    let res;
    try {
      res = await http(url, { headers: baseHeaders(this.host, this.jar) });
    } catch {
      return false;
    }
    this.jar.absorb(res);
    const html = await res.text();
    if (!html) return false;

    const m1 = html.match(/fn%28%22([0-9A-Fa-f]+)%22/) || html.match(/fn\("([0-9A-Fa-f]+)"/);
    if (m1) this.jsToken = decodeURIComponent(m1[1]);
    const m2 = html.match(/"pcftoken":"([a-f0-9]+)"/);
    if (m2) this.pcftoken = m2[1];
    return true;
  }

  common() {
    return {
      app_id: APP_ID,
      web: 1,
      channel: CHANNEL,
      clienttype: CLIENT_TYPE,
      jsToken: this.jsToken,
    };
  }
}

/* ------------------------------------------------------------------ */
/* Step 1 — share info + file list                                     */
/* ------------------------------------------------------------------ */

async function shareInfo(session, code) {
  const shorturl = code.startsWith('1') ? code : `1${code}`;
  const params = new URLSearchParams({
    app_id: APP_ID,
    shorturl,
    root: 1,
    ...session.common(),
  });

  const res = await http(`https://${session.host}/api/shorturlinfo?${params}`, {
    headers: baseHeaders(session.host, session.jar),
  });
  session.jar.absorb(res);
  const data = await readJson(res);
  if (!data) throw new ResolveError('UPSTREAM', 'TeraBox sent an unreadable response.');

  if (data.errno === 0) return data;
  if (data.errno === -9) {
    throw new ResolveError(
      'PASSWORD_REQUIRED',
      'This link is protected by an extraction code. Enter the 4-character code and try again.'
    );
  }
  throw new ResolveError(
    `ERRNO_${data.errno}`,
    ERRNO_MESSAGES[String(data.errno)] ||
      `TeraBox refused that link (code ${data.errno}). It may have expired.`
  );
}

/** Submit the extraction code; TeraBox answers with a BDCLND cookie. */
async function verifyPassword(session, code, pwd) {
  const params = new URLSearchParams({ app_id: APP_ID, surl: code });
  const res = await http(`https://${session.host}/share/verify?${params}`, {
    method: 'POST',
    headers: {
      ...baseHeaders(session.host, session.jar),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ pwd }).toString(),
  });
  session.jar.absorb(res);
  const data = await readJson(res);
  if (data && data.errno === 0) return true;
  if (data && (data.errno === -9 || data.errno === -12)) {
    throw new ResolveError(
      'BAD_PASSWORD',
      'That extraction code is not correct. Check the 4 characters the sender gave you.'
    );
  }
  throw new ResolveError(
    'BAD_PASSWORD',
    'That extraction code was rejected. Check the 4 characters the sender gave you.'
  );
}

/** Contents of a sub-folder inside a shared folder. */
async function listFolder(session, code, dir, page = 1) {
  const params = new URLSearchParams({
    app_id: APP_ID,
    shorturl: code.startsWith('1') ? code.slice(1) : code,
    root: 1,
    dir: dir || '',
    page: String(page),
    num: '200',
    web: 1,
    scene: '',
    ...session.common(),
  });
  const res = await http(`https://${session.host}/share/list?${params}`, {
    headers: baseHeaders(session.host, session.jar),
  });
  session.jar.absorb(res);
  const data = await readJson(res);
  if (!data) throw new ResolveError('UPSTREAM', 'TeraBox sent an unreadable response.');
  if (data.errno === 0 && Array.isArray(data.list)) return data.list;
  throw new ResolveError(
    `ERRNO_${data.errno}`,
    ERRNO_MESSAGES[String(data.errno)] || `TeraBox could not list that folder (code ${data.errno}).`
  );
}

/* ------------------------------------------------------------------ */
/* Step 2 — HLS streaming (works without any account)                  */
/* ------------------------------------------------------------------ */

function streamSign(session, timestamp) {
  return crypto
    .createHmac('sha1', STREAM_SALT)
    .update(`${CLIENT_TYPE}${CHANNEL}${session.browserid}${timestamp}`)
    .digest('hex');
}

/**
 * Build the HLS playlist URL for a video file.
 * @returns {string} absolute URL of the m3u8
 */
function buildStreamUrl(session, { uk, shareid, fsId, type = 'M3U8_AUTO_480' }) {
  const ts = Math.floor(Date.now() / 1000);
  const params = new URLSearchParams({
    ...session.common(),
    uk: String(uk),
    shareid: String(shareid),
    type,
    fid: String(fsId),
    sign: streamSign(session, ts),
    timestamp: String(ts),
    esl: '1',
    isplayer: '1',
    ehps: '1',
  });
  return `https://${session.host}/share/streaming?${params}`;
}

async function fetchPlaylist(session, { uk, shareid, fsId, type }) {
  const url = buildStreamUrl(session, { uk, shareid, fsId, type });
  const res = await http(url, { headers: baseHeaders(session.host, session.jar), timeout: 20000 });
  session.jar.absorb(res);
  const text = await res.text();
  if (!text) throw new ResolveError('UPSTREAM', 'TeraBox returned an empty playlist.');
  if (text.trimStart().startsWith('{')) {
    let j = {};
    try { j = JSON.parse(text); } catch { /* ignore */ }
    throw new ResolveError(
      `STREAM_${j.errno || 'ERR'}`,
      ERRNO_MESSAGES[String(j.errno)] ||
        'TeraBox cannot preview this file online right now. You can still download it.'
    );
  }
  if (!text.includes('#EXTM3U')) {
    throw new ResolveError('STREAM', 'TeraBox did not return a playable playlist for this file.');
  }
  return { url, playlist: text };
}

/* ------------------------------------------------------------------ */
/* Step 3 — direct download link (needs server-side credentials)        */
/* ------------------------------------------------------------------ */

/**
 * Ask TeraBox for a direct CDN link.
 *
 * Two credential modes are supported, in this order:
 *   1. `accessToken` — the official TeraBox Open Platform token
 *      (https://www.terabox.com/integrations/docs). This is the documented,
 *      ToS-friendly way to build a product like this.
 *   2. `cookie` — a logged-in TeraBox session (ndus) cookie.
 *
 * Without either, TeraBox answers errno 2 ("sign in required") — which is
 * exactly what the web app does for anonymous visitors.
 */
async function directLink(session, { uk, shareid, sign, timestamp, fsId, accessToken, cookie }) {
  if (accessToken) {
    const params = new URLSearchParams({
      access_tokens: accessToken,
      shareid: String(shareid),
      uk: String(uk),
      fid_list: JSON.stringify([fsId]),
    });
    const res = await http(`https://${session.host}/openapi/share/download?${params}`, {
      headers: baseHeaders(session.host, session.jar, {
        'Content-Type': 'application/x-www-form-urlencoded',
        ...(cookie ? { Cookie: cookie } : {}),
      }),
    });
    const data = await readJson(res);
    const dlink = data && (data.dlink || (data.list && data.list[0] && data.list[0].dlink));
    if (dlink) return dlink;
  }

  const params = new URLSearchParams({
    ...session.common(),
    shareid: String(shareid),
    uk: String(uk),
    sign: String(sign || ''),
    timestamp: String(timestamp || ''),
    primaryid: String(shareid),
    product: 'share',
    nozip: '0',
    fid_list: `[${fsId}]`,
  });
  const headers = baseHeaders(session.host, session.jar, {
    'Content-Type': 'application/x-www-form-urlencoded',
  });
  if (cookie) headers.Cookie = cookie;

  const res = await http(`https://${session.host}/share/download?${params}`, { headers });
  session.jar.absorb(res);
  const data = await readJson(res);
  if (data && data.errno === 0 && data.dlink) return data.dlink;

  const errno = data && data.errno;
  if (errno === 2 || errno === -6) {
    throw new ResolveError(
      'NEEDS_CREDENTIALS',
      'TeraBox only hands out direct links to a signed-in session. Add TERABOX_ACCESS_TOKEN (recommended) or TERABOX_COOKIE to the server environment.'
    );
  }
  throw new ResolveError(
    `DL_${errno}`,
    ERRNO_MESSAGES[String(errno)] || `TeraBox refused the download (code ${errno}).`
  );
}

/* ------------------------------------------------------------------ */
/* file shaping                                                        */
/* ------------------------------------------------------------------ */

const VIDEO_EXT = /\.(mp4|mkv|avi|mov|webm|flv|m4v|mpg|mpeg|ts|wmv|3gp|m3u8)$/i;
const AUDIO_EXT = /\.(mp3|m4a|aac|wav|flac|ogg|opus|wma)$/i;
const IMAGE_EXT = /\.(jpg|jpeg|png|gif|webp|bmp|svg|heic)$/i;
const ARCHIVE_EXT = /\.(zip|rar|7z|tar|gz|bz2|xz|iso)$/i;
const DOC_EXT = /\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|epub|rtf)$/i;

function categoryOf(name) {
  if (VIDEO_EXT.test(name)) return 'video';
  if (AUDIO_EXT.test(name)) return 'audio';
  if (IMAGE_EXT.test(name)) return 'image';
  if (ARCHIVE_EXT.test(name)) return 'archive';
  if (DOC_EXT.test(name)) return 'document';
  return 'file';
}

function humanSize(bytes) {
  const n = Number(bytes);
  if (!Number.isFinite(n) || n <= 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toFixed(v >= 100 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function shapeFile(item) {
  const name = item.server_filename || item.filename || item.path || 'file';
  const size = Number(item.size || 0);
  const thumbs = item.thumbs || {};
  return {
    fsId: String(item.fs_id),
    name,
    size,
    sizeText: humanSize(size),
    isDir: Number(item.isdir) === 1,
    path: item.path || '',
    category: categoryOf(name),
    md5: item.md5 || '',
    serverTime: item.server_ctime || item.server_mtime || 0,
    thumb: thumbs.url3 || thumbs.url2 || thumbs.url1 || thumbs.icon || '',
  };
}

/* ------------------------------------------------------------------ */
/* public API                                                          */
/* ------------------------------------------------------------------ */

/** Hosts that recently failed — skipped for a while so they cannot slow us. */
const hostCooldown = new Map();
const HOST_COOLDOWN_MS = 90 * 1000;

function hostIsDown(host) {
  const until = hostCooldown.get(host);
  if (!until) return false;
  if (Date.now() > until) {
    hostCooldown.delete(host);
    return false;
  }
  return true;
}

function markHostDown(host) {
  hostCooldown.set(host, Date.now() + HOST_COOLDOWN_MS);
}

/**
 * Run tasks with a bounded number in flight and resolve with the FIRST
 * success. If every task fails, resolve with the collected errors so the
 * caller can pick the most meaningful one.
 */
function raceWithConcurrency(tasks, limit) {
  return new Promise((resolve) => {
    const errors = [];
    let index = 0;
    let settled = false;

    const next = () => {
      if (settled) return;
      if (index >= tasks.length) {
        settled = true;
        resolve({ ok: false, errors });
        return;
      }
      const task = tasks[index++];
      Promise.resolve()
        .then(task)
        .then(
          (value) => {
            if (settled) return;
            settled = true;
            resolve({ ok: true, value });
          },
          (error) => {
            errors.push(error);
            next();
          }
        );
    };

    for (let i = 0; i < Math.min(limit, tasks.length); i++) next();
  });
}

/**
 * Resolve a TeraBox share link into a list of files.
 *
 * @param {object} opts
 * @param {string} opts.url        share link or bare code
 * @param {string} [opts.pwd]      extraction code (4 chars)
 * @param {string} [opts.dir]      sub-folder path inside a shared folder
 * @param {number} [opts.page]
 * @param {string} [opts.accessToken] TeraBox Open Platform token (optional)
 * @param {string} [opts.cookie]      logged-in TeraBox cookie (optional)
 */
async function resolveShare({ url, pwd = '', dir = '', page = 1, accessToken = '', cookie = '' }) {
  const parsed = parseShareUrl(url);
  const code = parsed.code;
  const pwdToUse = pwd || parsed.pwd;

  const hosts = [...new Set([parsed.host, ...FALLBACK_HOSTS])].filter((h) => !hostIsDown(h));
  if (!hosts.length) hosts.push(parsed.host);

  const tasks = [];
  for (const host of hosts) {
    for (const candidate of codeCandidates(code)) {
      tasks.push(() => resolveOnHost(host, candidate, pwdToUse, dir, page, accessToken, cookie));
    }
  }

  const results = await raceWithConcurrency(tasks, 4);
  if (results.ok) {
    results.value.originalCode = parsed.code;
    results.value.shareUrl = `https://${results.value.host}/s/${parsed.code}`;
    return results.value;
  }

  const errors = results.errors.filter(Boolean);
  const userError = errors.find((e) => ['PASSWORD_REQUIRED', 'BAD_PASSWORD'].includes(e.code));
  if (userError) throw userError;

  const meaningful = errors.find(
    (e) => e.code && !String(e.code).startsWith('ERRNO_') && e.code !== 'UPSTREAM'
  );
  throw meaningful || errors[0] || new ResolveError('UNREACHABLE', 'Could not reach TeraBox. Please try again in a moment.');
}

async function resolveOnHost(host, candidate, pwd, dir, page, accessToken, cookie) {
  const session = new Session(host);

  try {
    await session.bootstrap(candidate);
  } catch {
    /* continue anyway — some mirrors answer without a page load */
  }

  let info;
  try {
    info = await shareInfo(session, candidate);
  } catch (err) {
    if (err.code === 'PASSWORD_REQUIRED' && pwd) {
      await verifyPassword(session, candidate.replace(/^1/, ''), pwd);
      info = await shareInfo(session, candidate);
    } else {
      if (err.code === 'UPSTREAM') markHostDown(host);
      throw err;
    }
  }

  const files = info.list.map(shapeFile);

  // A sub-folder was requested: list that folder instead of the root.
  if (dir) {
    const list = await listFolder(session, candidate.replace(/^1/, ''), dir, page);
    const sub = list.map(shapeFile);
    return {
      host,
      code: candidate,
      session,
      shareid: info.shareid,
      uk: info.uk,
      sign: info.sign,
      timestamp: info.timestamp,
      title: info.title || '',
      shareUser: info.share_username || '',
      country: info.country || '',
      dir,
      page,
      files: sub,
      canDownload: !!(accessToken || cookie),
    };
  }

  // Try to attach a direct link to every file (needs credentials).
  let canDownload = false;
  if (accessToken || cookie) {
    canDownload = true;
    for (const file of files) {
      if (file.isDir) continue;
      try {
        file.dlink = await directLink(session, {
          uk: info.uk,
          shareid: info.shareid,
          sign: info.sign,
          timestamp: info.timestamp,
          fsId: file.fsId,
          accessToken,
          cookie,
        });
      } catch {
        file.dlink = '';
      }
    }
  }

  return {
    host,
    code: candidate,
    session,
    shareid: info.shareid,
    uk: info.uk,
    sign: info.sign,
    timestamp: info.timestamp,
    title: info.title || '',
    shareUser: info.share_username || '',
    country: info.country || '',
    dir: '',
    page,
    files,
    canDownload,
  };
}

module.exports = {
  resolveShare,
  shareInfo,
  listFolder,
  verifyPassword,
  buildStreamUrl,
  fetchPlaylist,
  directLink,
  streamSign,
  parseShareUrl,
  humanSize,
  categoryOf,
  Session,
  ResolveError,
  DEFAULT_UA,
  APP_ID,
};
