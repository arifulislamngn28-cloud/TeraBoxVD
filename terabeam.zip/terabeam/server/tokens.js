'use strict';
/**
 * Opaque, encrypted download tokens.
 *
 * The browser never sees a raw TeraBox CDN link or the share cookie — it only
 * ever holds an encrypted blob that this server can decrypt and verify.
 */
const crypto = require('crypto');

let cachedKey = null;
let cachedSecret = null;

function keyFor(secret) {
  if (cachedKey && cachedSecret === secret) return cachedKey;
  cachedSecret = secret;
  cachedKey = crypto.createHash('sha256').update(String(secret)).digest();
  return cachedKey;
}

/** @param {object} payload @param {string} secret */
function encrypt(payload, secret) {
  const key = keyFor(secret);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const json = Buffer.from(JSON.stringify(payload), 'utf8');
  const enc = Buffer.concat([cipher.update(json), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString('base64url');
}

/** @returns {object|null} decoded payload, or null when invalid/tampered */
function decrypt(token, secret) {
  try {
    const raw = Buffer.from(token, 'base64url');
    if (raw.length < 29) return null;
    const iv = raw.subarray(0, 12);
    const tag = raw.subarray(12, 28);
    const enc = raw.subarray(28);
    const key = keyFor(secret);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const out = Buffer.concat([decipher.update(enc), decipher.final()]);
    const payload = JSON.parse(out.toString('utf8'));
    if (!payload || typeof payload !== 'object') return null;
    if (payload.e && Date.now() > payload.e) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Random API key: tbx_ + 32 hex chars */
function generateApiKey() {
  return `tbx_${crypto.randomBytes(16).toString('hex')}`;
}

/** Random secret for a key's signing (unused by default, kept for expansion) */
function randomId(bytes = 8) {
  return crypto.randomBytes(bytes).toString('hex');
}

module.exports = { encrypt, decrypt, generateApiKey, randomId };
