'use strict';
/**
 * API key store for the developer API (/v1/api).
 *
 * Keys live in a small JSON file so they survive restarts. The file is
 * created on first write; the folder is git-ignored.
 */
const fs = require('fs');
const path = require('path');
const { generateApiKey, randomId } = require('./tokens');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const KEYS_FILE = path.join(DATA_DIR, 'keys.json');

const PLANS = {
  free: { label: 'Free', quota: 200 },
  starter: { label: 'Starter', quota: 5000 },
  pro: { label: 'Pro', quota: 50000 },
};

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function read() {
  try {
    const raw = fs.readFileSync(KEYS_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed.keys) ? parsed : { keys: [] };
  } catch {
    return { keys: [] };
  }
}

function write(store) {
  ensureDir();
  fs.writeFileSync(KEYS_FILE, JSON.stringify(store, null, 2), 'utf8');
}

function listKeys() {
  return read().keys;
}

function findKey(raw) {
  if (!raw) return null;
  const clean = String(raw).trim();
  return read().keys.find((k) => k.key === clean && k.active !== false) || null;
}

function createKey({ email, plan = 'free', autoApprove = true, note = '' }) {
  const store = read();
  const entry = {
    id: randomId(6),
    key: generateApiKey(),
    email: String(email || '').trim(),
    plan: PLANS[plan] ? plan : 'free',
    quota: PLANS[plan] ? PLANS[plan].quota : PLANS.free.quota,
    used: 0,
    active: !!autoApprove,
    note,
    createdAt: new Date().toISOString(),
  };
  store.keys.push(entry);
  write(store);
  return entry;
}

function setActive(id, active) {
  const store = read();
  const entry = store.keys.find((k) => k.id === id);
  if (!entry) return null;
  entry.active = !!active;
  write(store);
  return entry;
}

function countUsage(id) {
  const store = read();
  const entry = store.keys.find((k) => k.id === id);
  if (!entry) return null;
  entry.used = (entry.used || 0) + 1;
  write(store);
  return entry;
}

module.exports = { PLANS, listKeys, findKey, createKey, setActive, countUsage, KEYS_FILE, DATA_DIR };
