/**
 * TeraBeam - single source of truth for branding & site settings.
 *
 * CHANGE YOUR BRAND HERE. Everything (page titles, meta tags, logo, footer,
 * emails, analytics snippet placeholders) reads from this file.
 */
module.exports = {
  brand: {
    name: 'TeraBeam',
    domain: 'terabeam.com',
    url: process.env.SITE_URL || 'https://terabeam.com',
    tagline: 'Paste. Fetch. Done.',
    description:
      'Free TeraBox downloader & player. Paste any TeraBox share link and get a high-speed direct download link, or stream videos in your browser. No login, no app, no speed cap.',
    supportEmail: 'support@terabeam.com',
    telegram: '@terabeam',
    legalName: 'TeraBeam',
    legalType: 'Independent Project',
    jurisdiction: 'India',
  },

  colors: {
    primary: '#5b8cff',
    accent: '#a06bff',
    success: '#2fd48f',
    danger: '#ff6b6b',
  },

  /** Server behaviour toggles */
  runtime: {
    port: Number(process.env.PORT || 3000),
    /** 'proxy' streams bytes through this server (max reliability).
     *  'redirect' sends a 302 to the TeraBox CDN (saves bandwidth). */
    downloadMode: process.env.DOWNLOAD_MODE || 'proxy',
    /** Per-IP request budget for the public resolver, per 10 minutes. */
    rateLimit: Number(process.env.RATE_LIMIT || 60),
    /** Set to 'true' to auto-approve new API keys. */
    autoApproveKeys: String(process.env.AUTO_APPROVE_KEYS || 'true') === 'true',
    /** Secret used to encrypt download tokens. Change it in production. */
    secret: process.env.APP_SECRET || 'change-me-terabeam-secret-please',
    /**
     * TeraBox credentials (environment variables, not stored here).
     *
     * TeraBox only hands out a direct CDN link to an authenticated session.
     * Two supported ways to enable one-click downloads:
     *
     *   TERABOX_ACCESS_TOKEN  — a token from the official TeraBox Open
     *                           Platform (https://www.terabox.com/integrations/docs).
     *                           This is the documented route and the one to use.
     *   TERABOX_COOKIE        — a signed-in TeraBox session cookie (ndus=…).
     *                           Use it only if you understand the trade-offs.
     *
     * Without either one the site still works: it lists every file in a share
     * and streams videos in the browser.
     */
    teraboxAccessToken: process.env.TERABOX_ACCESS_TOKEN || '',
    teraboxCookie: process.env.TERABOX_COOKIE || '',
  },

  /** TeraBox share domains the resolver understands. */
  supportedDomains: [
    { host: 'terabox.com', note: 'Main domain' },
    { host: '1024terabox.com', note: 'Mirror' },
    { host: 'teraboxapp.com', note: 'Mirror' },
    { host: 'terabox.app', note: 'Mirror' },
    { host: 'freeterabox.com', note: 'Mirror' },
    { host: 'teraboxlink.com', note: 'Mirror' },
    { host: 'teraboxshare.com', note: 'Mirror' },
    { host: 'terasharelink.com', note: 'Mirror' },
    { host: 'terasharefile.com', note: 'Mirror' },
    { host: 'terafileshare.com', note: 'Mirror' },
    { host: '4funbox.com', note: 'Mirror' },
    { host: 'mirrobox.com', note: 'Mirror' },
    { host: 'nephobox.com', note: 'Mirror' },
    { host: '1024tera.com', note: 'Chinese mirror' },
    { host: 'tibibox.com', note: 'Mirror' },
    { host: '1024box.com', note: 'Mirror' },
    { host: 'xpanbox.com', note: 'Mirror' },
    { host: 'terabox.my', note: 'Mirror' },
    { host: 'qiwangbox.com', note: 'Mirror' },
    { host: 'terapk.com', note: 'Mirror' },
  ],
};
