/* TeraBeam — front-end logic (no build step, no dependencies) */
(function () {
  'use strict';

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  /* ---------------- toast ---------------- */
  function toast(msg, kind) {
    var host = $('.toast-host');
    if (!host) {
      host = document.createElement('div');
      host.className = 'toast-host';
      document.body.appendChild(host);
    }
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = msg;
    host.appendChild(el);
    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transition = 'opacity .3s';
      setTimeout(function () { el.remove(); }, 320);
    }, 3800);
  }

  /* ---------------- mobile nav ---------------- */
  var navToggle = $('.nav-toggle');
  if (navToggle) {
    navToggle.addEventListener('click', function () {
      var nav = $('.nav');
      if (nav) nav.classList.toggle('open');
    });
  }

  /* ---------------- icons ---------------- */
  var ICONS = {
    download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>'
  };

  function extOf(name) {
    var m = /\.([a-z0-9]{1,5})$/i.exec(name || '');
    return m ? m[1].toLowerCase() : 'file';
  }

  /* ---------------- the tool ---------------- */
  var form = $('#download-form');
  if (!form) return;

  var input = $('#share-url');
  var pwdInput = $('#share-pwd');
  var pwdRow = $('#pwd-row');
  var submitBtn = $('#submit-btn');
  var statusEl = $('#status');
  var resultEl = $('#result');
  var resultBody = $('#result-body');
  var resultMeta = $('#result-meta');
  var playerWrap = $('#player-wrap');
  var playerEl = $('#player');

  function setStatus(html, kind) {
    if (!statusEl) return;
    if (!html) { statusEl.innerHTML = ''; statusEl.hidden = true; return; }
    statusEl.hidden = false;
    statusEl.innerHTML =
      '<div class="alert ' + (kind || 'info') + '">' + (kind === 'error' ? ICONS.alert : ICONS.info) + '<div>' + html + '</div></div>';
  }

  function humanSize(bytes) {
    var n = Number(bytes) || 0;
    if (n <= 0) return '—';
    var units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return (i === 0 ? n : n.toFixed(n >= 100 ? 0 : 1)) + ' ' + units[i];
  }

  var hlsInstance = null;

  function showPlayer(url, name) {
    if (!playerWrap || !playerEl) return;
    playerWrap.hidden = false;
    if (playerEl.setAttribute) playerEl.setAttribute('title', name || '');

    if (window.Hls && window.Hls.isSupported()) {
      if (hlsInstance) { try { hlsInstance.destroy(); } catch (e) {} }
      hlsInstance = new window.Hls({ enableWorker: true, lowLatencyMode: false });
      hlsInstance.loadSource(url);
      hlsInstance.attachMedia(playerEl);
      hlsInstance.on(window.Hls.Events.MANIFEST_PARSED, function () {
        playerEl.play().catch(function () {});
      });
      hlsInstance.on(window.Hls.Events.ERROR, function (evt) {
        if (evt && evt.fatal) {
          setStatus('This stream could not be played here — use the download button instead.', 'warn');
        }
      });
    } else {
      playerEl.src = url;
      playerEl.play().catch(function () {});
    }
    playerWrap.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function renderFiles(data) {
    var share = data.share || {};
    var files = data.files || [];

    if (resultMeta) {
      var bits = [];
      if (share.title) bits.push(share.title);
      bits.push(files.length + ' file' + (files.length === 1 ? '' : 's'));
      if (share.totalSize) bits.push(share.totalSizeText || humanSize(share.totalSize));
      if (share.owner) bits.push(share.owner);
      resultMeta.textContent = bits.join(' · ');
    }

    if (!files.length) {
      resultBody.innerHTML =
        '<div class="alert warn">' + ICONS.alert + '<div>This share is empty — the owner has not added any files yet.</div></div>';
      return;
    }

    var html = '';
    if (share.dir) {
      html +=
        '<button class="btn btn-sm btn-ghost" id="js-back" style="margin-bottom:10px">' +
        '&larr; Back to the share root</button>';
    }

    html += '<div class="file-list">';
    files.forEach(function (f) {
      var isVideo = f.category === 'video' && f.streamUrl;
      var label = f.isDir ? ICONS.folder : extOf(f.name);
      var actions = '';
      if (isVideo) {
        actions += '<button class="icon-btn js-stream" title="Play in browser" data-url="' + escapeAttr(f.streamUrl) + '" data-name="' + escapeAttr(f.name) + '">' + ICONS.play + '</button>';
      }
      if (f.hasDirect) {
        actions += '<a class="icon-btn js-download" title="Download" href="' + escapeAttr(f.downloadUrl) + '" download>' + ICONS.download + '</a>';
      } else if (!f.isDir) {
        actions += '<a class="icon-btn js-open" title="Open in TeraBox" href="' + escapeAttr(f.openUrl) + '" target="_blank" rel="noopener">' + ICONS.external + '</a>';
      }
      var nameCell = f.isDir
        ? '<button class="file-name js-folder" data-dir="' + escapeAttr(f.path) + '" style="background:none;border:0;padding:0;text-align:left;cursor:pointer;color:inherit;font:inherit">' + escapeHtml(f.name) + '</button>'
        : '<div class="file-name" title="' + escapeHtml(f.name) + '">' + escapeHtml(f.name) + '</div>';
      html +=
        '<div class="file-item">' +
        '<div class="file-icon ' + (f.category || 'file') + '">' + (f.isDir ? ICONS.folder : label) + '</div>' +
        '<div class="file-meta">' +
        nameCell +
        '<div class="file-size">' + (f.sizeText || humanSize(f.size)) + (f.isDir ? ' · folder' : '') + '</div>' +
        '</div>' +
        '<div class="file-actions">' + actions + '</div>' +
        '</div>';
    });
    html += '</div>';

    if (!data.canDownload) {
      html +=
        '<div class="alert info" style="margin-top:12px">' + ICONS.info +
        '<div>Video files play right here. For a one-click download of the original file, ' +
        'the site owner needs a TeraBox API token — the link opens the official TeraBox page in the meantime.</div></div>';
    }
    resultBody.innerHTML = html;

    $$('.js-stream', resultBody).forEach(function (btn) {
      btn.addEventListener('click', function () {
        showPlayer(btn.getAttribute('data-url'), btn.getAttribute('data-name'));
      });
    });

    $$('.js-folder', resultBody).forEach(function (btn) {
      btn.addEventListener('click', function () {
        currentDir = btn.getAttribute('data-dir');
        doResolve();
      });
    });

    var back = $('#js-back', resultBody);
    if (back) {
      back.addEventListener('click', function () {
        currentDir = '';
        doResolve();
      });
    }
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function escapeAttr(s) {
    return escapeHtml(s);
  }

  var currentDir = '';

  function doResolve() {
    var url = (input.value || '').trim();
    if (!url) {
      setStatus('Paste a TeraBox share link first.', 'error');
      input.focus();
      return;
    }

    submitBtn.disabled = true;
    var original = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> Working…';
    setStatus('Reading the share…', 'info');
    if (resultEl) resultEl.hidden = true;
    if (playerWrap) playerWrap.hidden = true;

    var payload = {
      url: url,
      pwd: pwdInput ? (pwdInput.value || '').trim() : '',
      dir: currentDir
    };

    fetch('/api/resolve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); })
      .then(function (res) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = original;

        if (res.body && res.body.ok) {
          if (pwdRow) pwdRow.classList.remove('show');
          setStatus('Done — ' + (res.body.ms || 0) + 'ms.', 'info');
          if (resultEl) resultEl.hidden = false;
          renderFiles(res.body);
          if (resultEl) resultEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          return;
        }

        var code = res.body && res.body.code;
        var msg = (res.body && res.body.error) || 'Could not read that link.';

        if (code === 'PASSWORD_REQUIRED' && pwdRow) {
          pwdRow.classList.add('show');
          setStatus(msg + ' <b>Enter the code below and press the button again.</b>', 'warn');
          pwdInput.focus();
          return;
        }
        if (code === 'BAD_PASSWORD' && pwdRow) {
          pwdRow.classList.add('show');
          setStatus(msg, 'error');
          pwdInput.focus();
          return;
        }
        setStatus(escapeHtml(msg), 'error');
      })
      .catch(function () {
        submitBtn.disabled = false;
        submitBtn.innerHTML = original;
        setStatus('Network problem. Please try again.', 'error');
      });
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    currentDir = '';
    doResolve();
  });

  /* paste from clipboard */
  var pasteBtn = $('#paste-btn');
  if (pasteBtn) {
    pasteBtn.addEventListener('click', function () {
      if (!navigator.clipboard || !navigator.clipboard.readText) {
        toast('Your browser blocked clipboard access — just paste with Ctrl+V.', 'error');
        return;
      }
      navigator.clipboard.readText().then(function (text) {
        if (text && text.trim()) {
          input.value = text.trim();
          input.focus();
        } else {
          toast('Clipboard is empty.', 'error');
        }
      }).catch(function () {
        toast('Clipboard access denied — paste manually.', 'error');
      });
    });
  }

  /* copy buttons */
  $$('.js-copy').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var text = btn.getAttribute('data-copy') || '';
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function () {
          toast('Copied to clipboard', 'ok');
        }).catch(function () { toast('Copy failed', 'error'); });
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); toast('Copied to clipboard', 'ok'); }
        catch (e) { toast('Copy failed', 'error'); }
        ta.remove();
      }
    });
  });

  /* API key request form */
  var keyForm = $('#key-form');
  if (keyForm) {
    keyForm.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var email = $('#key-email');
      var out = $('#key-result');
      var btn = $('#key-submit');
      btn.disabled = true;
      var original = btn.innerHTML;
      btn.innerHTML = '<span class="spinner"></span>';
      fetch('/api/keys/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: (email.value || '').trim() })
      })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          btn.disabled = false;
          btn.innerHTML = original;
          if (!j.ok) { out.innerHTML = '<div class="alert error">' + ICONS.alert + '<div>' + escapeHtml(j.error) + '</div></div>'; return; }
          var html = '<div class="alert info">' + ICONS.info + '<div>' + escapeHtml(j.message);
          if (j.key) {
            html += '<br><code class="mono" style="word-break:break-all">' + escapeHtml(j.key) + '</code>' +
              '<br><button class="btn btn-sm btn-ghost js-copy" data-copy="' + escapeAttr(j.key) + '" style="margin-top:8px">Copy key</button>';
          }
          html += '</div></div>';
          out.innerHTML = html;
          var c = $('.js-copy', out);
          if (c) c.addEventListener('click', function () {
            navigator.clipboard.writeText(j.key).then(function () { toast('Copied to clipboard', 'ok'); });
          });
        })
        .catch(function () {
          btn.disabled = false; btn.innerHTML = original;
          out.innerHTML = '<div class="alert error">' + ICONS.alert + '<div>Network problem. Please try again.</div></div>';
        });
    });
  }

  /* prefill from ?url= */
  var params = new URLSearchParams(window.location.search);
  var pre = params.get('url');
  if (pre && input) {
    input.value = pre;
    if (params.get('autostart') === '1') {
      setTimeout(function () { form.dispatchEvent(new Event('submit', { cancelable: true })); }, 200);
    }
  }
})();
