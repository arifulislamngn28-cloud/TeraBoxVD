'use strict';
/**
 * End-to-end test for TeraBeam.
 *
 *   node tools/test-site.js
 *   node tools/test-site.js "https://www.terabox.com/s/1AbCdEf…"
 *
 * Starts nothing itself — point it at a running server:
 *   node tools/test-site.js http://localhost:3000 "<url>"
 */
const { spawn } = require('child_process');
const path = require('path');

const PORT = Number(process.env.TEST_PORT || 3210);
const BASE = process.argv[2] && /^https?:\/\//.test(process.argv[2]) ? process.argv[2] : `http://127.0.0.1:${PORT}`;
const URL_ARG = process.argv[2] && /^https?:\/\//.test(process.argv[2]) ? process.argv[3] : process.argv[2];
const LINK = URL_ARG || 'https://www.terabox.com/s/1AFacZXKofDvzAlPxK6ZUUg';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let pass = 0;
let fail = 0;
function check(name, ok, detail = '') {
  if (ok) {
    pass += 1;
    console.log(`  \x1b[32m✓\x1b[0m ${name}${detail ? ` — ${detail}` : ''}`);
  } else {
    fail += 1;
    console.log(`  \x1b[31m✗\x1b[0m ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

async function waitForServer(url, tries = 30) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(`${url}/healthz`);
      if (r.ok) return true;
    } catch {
      /* not up yet */
    }
    await sleep(400);
  }
  return false;
}

(async () => {
  const own = !/^https?:\/\//.test(process.argv[2] || '');
  let child = null;

  if (own) {
    console.log(`starting server on ${PORT}…`);
    child = spawn('node', [path.join(__dirname, '..', 'server', 'index.js')], {
      env: { ...process.env, PORT: String(PORT) },
      stdio: 'ignore',
    });
    if (!(await waitForServer(BASE))) {
      console.error('server did not come up');
      child.kill();
      process.exit(1);
    }
  }

  console.log(`\nTeraBeam end-to-end test against ${BASE}\n`);

  try {
    // 1. health
    const health = await (await fetch(`${BASE}/healthz`)).json();
    check('server is healthy', health.ok === true, `downloadsEnabled=${health.downloadsEnabled}`);

    // 2. pages
    for (const p of ['/', '/about/', '/faq/', '/api/', '/supported-domains/', '/privacy-policy/', '/terms/']) {
      const r = await fetch(`${BASE}${p}`);
      check(`page ${p}`, r.status === 200, `HTTP ${r.status}`);
    }

    // 3. resolve
    const started = Date.now();
    const res = await fetch(`${BASE}/api/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: LINK }),
    });
    const data = await res.json();
    check('POST /api/resolve returns ok', data.ok === true, data.error || `${Date.now() - started}ms`);
    if (!data.ok) throw new Error('resolve failed, stopping');

    check('share has files', (data.files || []).length > 0, `${data.files.length} file(s)`);
    check('file metadata present', !!(data.files[0].name && data.files[0].sizeText), data.files[0].sizeText);

    // 4. bad input
    const bad = await (
      await fetch(`${BASE}/api/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: 'not-a-link' }),
      })
    ).json();
    check('invalid link is rejected politely', bad.ok === false && !!bad.error, bad.error || '');

    // 5. streaming
    const video = (data.files || []).find((f) => f.streamUrl);
    if (video) {
      const m3u8 = await fetch(`${BASE}${video.streamUrl}`);
      const text = await m3u8.text();
      check('playlist is served', m3u8.status === 200 && text.includes('#EXTM3U'), `${text.length} bytes`);

      const seg = (text.match(/^(https?:\/\/\S+)$/m) || [])[0];
      if (seg) {
        const sres = await fetch(seg);
        const buf = Buffer.from(await sres.arrayBuffer());
        const isTs = buf.length > 1000 && buf[0] === 0x47 && buf[1] === 0x40;
        check('segment proxy delivers video bytes', sres.status === 200 && isTs, `${buf.length} bytes, MPEG-TS=${isTs}`);
      } else {
        check('segment url present', false, 'no segment found in playlist');
      }
    } else {
      console.log('  \x1b[33m•\x1b[0m no video in this share — skipping the stream test');
    }
  } catch (err) {
    fail += 1;
    console.error('  \x1b[31m! test run failed:\x1b[0m', err.message);
  }

  console.log(`\n  ${pass} passed, ${fail} failed\n`);
  if (child) child.kill();
  process.exit(fail ? 1 : 0);
})();
