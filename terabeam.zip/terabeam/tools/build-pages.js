'use strict';
/**
 * Static page generator for TeraBeam.
 *
 * Edit the CONTENT blocks below (or site.config.js for branding) and run:
 *     node tools/build-pages.js
 *
 * Output is plain static HTML in public/ — deployable on any host.
 */
const fs = require('fs');
const path = require('path');

const config = require('../site.config');
const B = config.brand;

const OUT = path.join(__dirname, '..', 'public');

/* ------------------------------------------------------------------ */
/* shared fragments                                                    */
/* ------------------------------------------------------------------ */

const ICON = {
  bolt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polygon points="10 8 16 12 10 16" fill="currentColor" stroke="none"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/></svg>',
  code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
};

const NAV = [
  { href: '/', label: 'Downloader' },
  { href: '/supported-domains/', label: 'Supported links' },
  { href: '/faq/', label: 'FAQ' },
  { href: '/api/', label: 'API' },
  { href: '/about/', label: 'About' },
  { href: '/contact/', label: 'Contact' },
];

function header(active) {
  return `
  <header class="site-header">
    <div class="wrap header-inner">
      <a class="brand" href="/">
        <span class="brand-mark">${ICON.bolt}</span>
        <span>${B.name}<small>TeraBox direct links</small></span>
      </a>
      <button class="nav-toggle" aria-label="Menu">${ICON.menu}</button>
      <nav class="nav">
        ${NAV.map((n) => `<a href="${n.href}"${n.href === active ? ' class="active"' : ''}>${n.label}</a>`).join('\n        ')}
        <a class="btn btn-sm" href="/#tool">Open tool</a>
      </nav>
    </div>
  </header>`;
}

function footer() {
  const year = new Date().getFullYear();
  return `
  <footer class="site-footer">
    <div class="wrap">
      <div class="footer-grid">
        <div class="footer-about">
          <a class="brand" href="/">
            <span class="brand-mark">${ICON.bolt}</span>
            <span>${B.name}<small>TeraBox direct links</small></span>
          </a>
          <p style="margin-top:14px">${B.description}</p>
        </div>
        <div>
          <h4>Tool</h4>
          <ul>
            <li><a href="/">Downloader</a></li>
            <li><a href="/supported-domains/">Supported links</a></li>
            <li><a href="/blog/how-to-download-from-terabox/">How to download</a></li>
            <li><a href="/api/">Developer API</a></li>
          </ul>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li><a href="/about/">About us</a></li>
            <li><a href="/contact/">Contact</a></li>
            <li><a href="/faq/">FAQ</a></li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li><a href="/privacy-policy/">Privacy policy</a></li>
            <li><a href="/terms/">Terms of service</a></li>
            <li><a href="mailto:${B.supportEmail}">${B.supportEmail}</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${year} ${B.legalName}. All rights reserved.</span>
        <span>Not affiliated with TeraBox or Flextech Inc.</span>
      </div>
      <p class="disclaimer" style="margin-top:14px">
        ${B.name} is an independent, free tool that turns a public TeraBox share link into a direct link.
        We do not host, store, or inspect any file. All file bytes travel directly between TeraBox's own
        servers and your device. Use ${B.name} only for files you own or have permission to download.
      </p>
    </div>
  </footer>`;
}

function layout({ slug, title, description, body, active, extraHead = '' }) {
  const canonical = `${B.url}/${slug ? `${slug}/` : ''}`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<meta name="description" content="${description}">
<link rel="canonical" href="${canonical}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${B.name}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:url" content="${canonical}">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#070912">
<link rel="icon" href="/assets/logo.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js" defer></script>
${extraHead}
</head>
<body>
${header(active)}
<main>
${body}
</main>
${footer()}
<script src="/assets/app.js"></script>
</body>
</html>
`;
}

/* ------------------------------------------------------------------ */
/* the tool block (reused on home + a couple of pages)                  */
/* ------------------------------------------------------------------ */

function toolBlock() {
  return `
  <section class="section" id="tool" style="padding-top:8px">
    <div class="wrap">
      <div class="tool-card">
        <form id="download-form" autocomplete="off">
          <div class="tool-row">
            <div class="tool-input">
              <input id="share-url" type="url" name="url" inputmode="url" spellcheck="false"
                     placeholder="Paste your TeraBox link — terabox.com/s/1AbCdEf…" aria-label="TeraBox share link">
              <button type="button" class="paste-btn" id="paste-btn">Paste</button>
            </div>
            <button type="submit" class="btn btn-lg" id="submit-btn">Get files</button>
          </div>
          <div class="pwd-row" id="pwd-row">
            <input id="share-pwd" type="text" maxlength="4" placeholder="Extraction code (4 characters)" aria-label="Extraction code">
            <button type="submit" class="btn">Unlock</button>
          </div>
        </form>
        <p class="hint">
          Works with every TeraBox domain and mirror. No account, no app. Videos stream in your browser.
        </p>
        <div id="status" hidden></div>
        <div class="result" id="result" hidden>
          <div class="result-head">
            <div class="result-title">Files in this share</div>
            <div class="result-meta" id="result-meta"></div>
          </div>
          <div id="result-body"></div>
        </div>
      </div>
      <div class="player-wrap" id="player-wrap" hidden>
        <video id="player" controls playsinline preload="metadata"></video>
      </div>
      <div class="supported-inline">
        ${config.supportedDomains.slice(0, 12).map((d) => `<span class="chip">${d.host}</span>`).join('\n        ')}
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ */
/* pages                                                               */
/* ------------------------------------------------------------------ */

const PAGES = [];

PAGES.push({
  slug: '',
  file: 'index.html',
  active: '/',
  title: `${B.name} — Free TeraBox Downloader & Online Player`,
  description: B.description,
  body: `
  <section class="hero">
    <div class="wrap center">
      <span class="badge"><span class="dot"></span> Free · No login · No app required</span>
      <h1>Open a TeraBox link <span class="gradient-text">without the app</span></h1>
      <p class="lead">
        Paste a TeraBox share link. ${B.name} reads the share, lists every file inside it and plays videos
        straight in your browser. No install, no TeraBox account, no waiting room, no ads before the file.
      </p>
    </div>
  </section>

  ${toolBlock()}

  <section class="section">
    <div class="wrap">
      <div class="section-head">
        <span class="eyebrow">Why ${B.name}</span>
        <h2>Built to get out of the way</h2>
        <p class="lead">The four things people actually complain about with the normal TeraBox flow — all gone.</p>
      </div>
      <div class="grid grid-4">
        <div class="card">
          <div class="card-icon">${ICON.bolt}</div>
          <h3>No app, no sign-up</h3>
          <p>Public share metadata needs no TeraBox account, so you never install anything or hand over a password.</p>
        </div>
        <div class="card">
          <div class="card-icon">${ICON.clock}</div>
          <h3>No waiting room</h3>
          <p>No 30-second countdown, no “your download will start soon” page, no fake progress bar.</p>
        </div>
        <div class="card">
          <div class="card-icon">${ICON.play}</div>
          <h3>Stream in the browser</h3>
          <p>Videos play on the page with a seek bar, so you can check a clip before pulling the whole file down.</p>
        </div>
        <div class="card">
          <div class="card-icon">${ICON.shield}</div>
          <h3>Nothing stored</h3>
          <p>Links are processed in memory and discarded. We never store, mirror or inspect your files.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section alt">
    <div class="wrap">
      <div class="section-head">
        <span class="eyebrow">How it works</span>
        <h2>Three steps, about fifteen seconds</h2>
      </div>
      <div class="steps">
        <div class="step">
          <h3>Copy the link</h3>
          <p>Open the share in TeraBox and copy the URL. It looks like <code class="mono">terabox.com/s/1AbCdEf…</code></p>
        </div>
        <div class="step">
          <h3>Paste it here</h3>
          <p>Drop the link into the box above and press <b>Get direct link</b>. A 4-character extraction code is only needed if the sender set one.</p>
        </div>
        <div class="step">
          <h3>See what is inside</h3>
          <p>Every file in the share is listed with its size and type — video, image, document, archive or audio.</p>
        </div>
        <div class="step">
          <h3>Play or save</h3>
          <p>Press play to stream a video on the page, or download the original file with one click.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="section-head">
        <span class="eyebrow">Every mirror</span>
        <h2>All TeraBox domains, all link shapes</h2>
        <p class="lead">TeraBox runs on many mirror domains and uses two different link formats. ${B.name} reads both, so it never says "invalid link" on a link that actually works.</p>
      </div>
      <div class="domain-list" style="justify-content:center">
        ${config.supportedDomains.map((d) => `<code>${d.host}</code>`).join('\n        ')}
      </div>
      <div class="center" style="margin-top:26px">
        <a class="btn btn-ghost" href="/supported-domains/">See the full list</a>
      </div>
    </div>
  </section>

  <section class="section alt">
    <div class="wrap">
      <div class="section-head">
        <span class="eyebrow">FAQ</span>
        <h2>Questions people keep asking</h2>
      </div>
      <div class="accordion">
        ${[
          ['Do I need a TeraBox account?',
           'No. The link you paste is a public share link, and public share metadata is readable without signing in. ${B.name} never asks for your TeraBox password.'],
          ['Can I watch a video without downloading it?',
           'Yes. Press the play button next to any video file and it plays on the page with a seek bar. The stream is proxied through our server, so the quality you get is whatever TeraBox has transcoded for that file.'],
          ['Does it work on a phone?',
           'Yes. The interface is built mobile-first, and the download button saves straight to your phone’s Downloads folder.'],
          ['Can I download a whole shared folder?',
           'Yes. Every file inside a shared folder is listed individually with its own link, and you can pick the ones you want.'],
          ['Is it free?',
           'Yes — completely free, with no daily quota and no premium tier.'],
          ['Is it affiliated with TeraBox?',
           'No. ${B.name} is an independent tool. We are not connected to TeraBox or Flextech Inc.'],
        ]
          .map(
            ([q, a]) => `<details><summary>${q}</summary><div class="answer"><p>${a.replace(/\$\{B\.name\}/g, B.name)}</p></div></details>`
          )
          .join('\n        ')}
      </div>
      <div class="center" style="margin-top:26px">
        <a class="btn btn-ghost" href="/faq/">Read the full FAQ</a>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="cta-box">
        <h2>Ready to grab that file?</h2>
        <p>Paste your link above. It takes about as long as loading a webpage.</p>
        <a class="btn btn-lg" href="#tool">Open the downloader</a>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'about',
  file: 'about.html',
  active: '/about/',
  title: `About ${B.name} — Free TeraBox Direct Link Tool`,
  description: `What ${B.name} is, how it works, and what we promise: we do not host, store or inspect any file, and every byte travels directly from TeraBox to you.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">About us</span>
      <h1>A faster, cleaner way to open a <span class="gradient-text">TeraBox share link</span></h1>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="prose">
        <h2>Our mission</h2>
        <p>
          Getting a file out of a TeraBox share should be simple, fast and predictable. In practice it usually
          means installing the app, logging in, watching an advert, and waiting out a countdown while the
          transfer crawls. ${B.name} removes that whole detour: you paste a public share link and the tool
          resolves it into a clean, direct download link.
        </p>

        <h2>What we do</h2>
        <ul>
          <li>Read public TeraBox share links and list every file inside them.</li>
          <li>Produce direct download links that bypass the app-only flow and its artificial delay.</li>
          <li>Stream supported video files in the browser with seeking.</li>
          <li>Accept every TeraBox domain and mirror, in both link formats.</li>
        </ul>

        <h2>What we do not do</h2>
        <ul>
          <li>We do not host, store, mirror or keep a copy of any file.</li>
          <li>We do not ask for, need or want your TeraBox login.</li>
          <li>We do not inspect, analyse or report on the contents of what you download.</li>
          <li>We do not index shares, and we do not build a catalogue of them.</li>
        </ul>

        <div class="note">
          Every file byte travels directly between TeraBox’s own content servers and your own device.
          ${B.name} only performs the lookup that turns a share page into a direct address.
        </div>

        <h2>Fair use</h2>
        <p>
          ${B.name} is built for legitimate use: your own files, files a friend has shared with you, and
          material that is openly licensed for redistribution. Downloading copyrighted work without permission
          is not something we support, and misuse of the service may get your requests blocked.
        </p>

        <h2>Who we are</h2>
        <p>
          ${B.name} is an independent project by ${B.legalName}. We are not affiliated with, endorsed by, or
          connected to TeraBox or Flextech Inc. All product names and logos referenced here belong to their
          respective owners.
        </p>

        <h2>Get in touch</h2>
        <p>
          Questions, bug reports or a link that will not resolve? Write to
          <a href="mailto:${B.supportEmail}">${B.supportEmail}</a> or use the
          <a href="/contact/">contact page</a>.
        </p>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'faq',
  file: 'faq.html',
  active: '/faq/',
  title: `TeraBox Downloader FAQ — ${B.name}`,
  description: `Answers to common questions about ${B.name}: which TeraBox links work, whether an account is needed, which file types are supported, and how to fix an error.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">FAQ</span>
      <h1>Questions, <span class="gradient-text">answered</span></h1>
      <p class="lead">Everything people usually ask before they paste their first link.</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="accordion">
        ${[
          ['Which TeraBox links work?',
           'Any public share link. Both shapes are supported — the path form <code class="mono">terabox.com/s/1AbCdEf…</code> and the query form <code class="mono">terabox.com/sharing/link?surl=1AbCdEf…</code> — on every TeraBox domain and mirror. See the <a href="/supported-domains/">full domain list</a>.'],
          ['Do I need a TeraBox account or the app?',
           'No. ${B.name} reads public share metadata without any sign-in, and there is nothing to install.'],
          ['What if the link asks for a 4-character code?',
           'The sender set an extraction code on the share. Type it into the code field that appears and press Unlock. Only the sender can give it to you.'],
          ['Which file types can I download?',
           'Whatever is inside the share: MP4, MKV, AVI, MOV and WebM video, JPG and PNG images, PDF and Office documents, MP3 and FLAC audio, and ZIP, RAR or 7z archives.'],
          ['Can I download a shared folder?',
           'Yes. Every file inside the folder is listed separately with its own direct link, so you can take just the ones you want.'],
          ['Can I stream a video instead of downloading it?',
           'Yes. Press the play button next to any video file and it plays on the page, with a seek bar. The transfer is proxied through our server, so a stable connection helps.'],
          ['Why is the link expired / invalid?',
           'Either the owner deleted the share or set it to expire, or the code was copied incompletely. Open the link in a normal browser tab to check — if it does not load there either, the file is gone.'],
          ['Is there a daily limit?',
           'The public tool has a light anti-abuse limit per IP. If you hit it, wait a few minutes. API users get their own quota.'],
          ['Does ${B.name} store my files?',
           'No. Links are processed in memory and discarded. We keep no copy of any file and no list of the links you have opened.'],
          ['Is ${B.name} free?',
           'Yes, entirely free for the web tool. If you are building something on top of it, the <a href="/api/">developer API</a> is free too for light use.'],
          ['Can I use ${B.name} for commercial downloads?',
           'Only for material you have the right to download. The tool does not grant any rights over the files it resolves.'],
          ['Which browser should I use?',
           'Any current browser. On iOS, MKV files will not preview in Safari and need a player such as VLC; MP4 and MOV play natively.'],
        ]
          .map(([q, a]) => `<details><summary>${q}</summary><div class="answer"><p>${a.replace(/\$\{B\.name\}/g, B.name)}</p></div></details>`)
          .join('\n        ')}
      </div>
    </div>
  </section>
  <section class="section">
    <div class="wrap">
      <div class="cta-box">
        <h2>Still stuck?</h2>
        <p>Tell us the link format you are using and we will add it to the resolver.</p>
        <a class="btn btn-lg" href="/contact/">Contact support</a>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'supported-domains',
  file: 'supported-domains.html',
  active: '/supported-domains/',
  title: `Supported TeraBox Domains & Link Formats — ${B.name}`,
  description: `Every TeraBox domain and mirror that ${B.name} can read, plus both share link formats and how to copy them correctly.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Supported links</span>
      <h1>Every TeraBox domain, <span class="gradient-text">both link formats</span></h1>
      <p class="lead">TeraBox runs on many mirror domains and hands out links in two shapes. ${B.name} reads all of them.</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <h3>Domains we can read</h3>
      <div class="domain-list" style="margin-bottom:38px">
        ${config.supportedDomains.map((d) => `<code>${d.host}</code>`).join('\n        ')}
      </div>

      <h3>The two link shapes</h3>
      <div class="grid grid-2" style="margin-bottom:38px">
        <div class="card">
          <h3>Path form</h3>
          <p style="margin-bottom:12px">The code sits in the path, right after <code class="mono">/s/</code>.</p>
          <pre><span class="c"># path form</span>
https://www.terabox.com/s/<span class="k">1AbCdEfGhIjKlMn</span>
https://1024terabox.com/s/<span class="k">1AbCdEfGhIjKlMn</span></pre>
        </div>
        <div class="card">
          <h3>Query form</h3>
          <p style="margin-bottom:12px">The code sits in the query string as <code class="mono">surl</code>.</p>
          <pre><span class="c"># query form</span>
https://www.terabox.com/sharing/link?surl=<span class="k">1AbCdEfGhIjKlMn</span>
https://www.1024tera.com/chinese/sharing/link?surl=<span class="k">1AbCdEfGhIjKlMn</span></pre>
        </div>
      </div>

      <h3>How to copy it correctly</h3>
      <div class="table-wrap" style="margin-top:16px">
        <table>
          <thead><tr><th>What you did</th><th>What happens</th></tr></thead>
          <tbody>
            <tr><td>Copied the whole address bar</td><td><span class="win">Works</span> — this is the right way</td></tr>
            <tr><td>Copied only the code, no domain</td><td><span class="win">Works</span> — the code alone is enough</td></tr>
            <tr><td>Truncated the code in the middle</td><td><span class="lose">Invalid link</span></td></tr>
            <tr><td>Copied a link to a TeraBox login page</td><td><span class="lose">No share code found</span></td></tr>
            <tr><td>Copied a link to a deleted share</td><td><span class="lose">Expired or not found</span></td></tr>
          </tbody>
        </table>
      </div>

      <div class="note">
        TeraBox can add or retire mirror domains without notice. If a link stops working and it is a domain
        that is not on this list, <a href="/contact/">tell us</a> and we will add it.
      </div>
    </div>
  </section>
  <section class="section">
    <div class="wrap">
      <div class="cta-box">
        <h2>Try it on your own link</h2>
        <p>Every domain on this list works with the same box.</p>
        <a class="btn btn-lg" href="/#tool">Open the downloader</a>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'api',
  file: 'api.html',
  active: '/api/',
  title: `TeraBox Developer API — Direct Links as JSON | ${B.name}`,
  description: `Resolve any TeraBox share link to JSON with file names, sizes and direct download links. One endpoint, one header, generous free quota.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Developer API</span>
      <h1>Direct links as <span class="gradient-text">JSON</span></h1>
      <p class="lead">One endpoint turns a TeraBox share link into a file list with working download and stream URLs.</p>
    </div>
  </section>

  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="grid grid-2" style="align-items:start">
        <div>
          <h3>Get a key</h3>
          <p style="margin-bottom:16px">Keys are free. Enter your email and the key appears instantly.</p>
          <div class="tool-card" style="margin:0">
            <form id="key-form" autocomplete="off">
              <div class="tool-row">
                <div class="tool-input">
                  <input id="key-email" type="email" placeholder="you@example.com" aria-label="Email address" required>
                </div>
                <button type="submit" class="btn" id="key-submit">Get key</button>
              </div>
            </form>
            <div id="key-result"></div>
          </div>
          <div class="note" style="margin-top:20px">
            Keys are stored locally on the server. We send no marketing mail, and you can ask us to delete
            your key at any time by writing to <a href="mailto:${B.supportEmail}">${B.supportEmail}</a>.
          </div>
        </div>

        <div>
          <h3>Endpoint</h3>
          <pre><span class="c"># resolve a share link</span>
POST ${B.url}/v1/api
Content-Type: application/json
X-API-Key: tbx_your_key_here

{
  <span class="s">"url"</span>: <span class="s">"https://terabox.com/s/1AbCdEf…"</span>,
  <span class="s">"pwd"</span>: <span class="s">""</span>,
  <span class="s">"dir_path"</span>: <span class="s">""</span>,
  <span class="s">"page"</span>: <span class="k">1</span>
}</pre>

          <h3 style="margin-top:26px">Response</h3>
          <pre>{
  <span class="s">"ok"</span>: <span class="k">true</span>,
  <span class="s">"share"</span>: { <span class="s">"fileCount"</span>: <span class="k">3</span> },
  <span class="s">"files"</span>: [
    {
      <span class="s">"fs_id"</span>: <span class="s">"1234567890"</span>,
      <span class="s">"filename"</span>: <span class="s">"clip.mp4"</span>,
      <span class="s">"size"</span>: <span class="k">84561234</span>,
      <span class="s">"size_readable"</span>: <span class="s">"80.64 MB"</span>,
      <span class="s">"category"</span>: <span class="s">"video"</span>,
      <span class="s">"download_url"</span>: <span class="s">"https://…"</span>,
      <span class="s">"stream_url"</span>: <span class="s">"https://…"</span>
    }
  ],
  <span class="s">"usage"</span>: { <span class="s">"used"</span>: <span class="k">1</span>, <span class="s">"quota"</span>: <span class="k">200</span> }
}</pre>
        </div>
      </div>

      <h3 style="margin-top:44px">Example with cURL</h3>
      <pre>curl -X POST ${B.url}/v1/api \\
  -H <span class="s">"Content-Type: application/json"</span> \\
  -H <span class="s">"X-API-Key: tbx_your_key_here"</span> \\
  -d <span class="s">'{"url":"https://terabox.com/s/1AbCdEf…"}'</span></pre>

      <h3 style="margin-top:44px">Example with JavaScript</h3>
      <pre><span class="k">const</span> res = <span class="k">await</span> fetch(<span class="s">"${B.url}/v1/api"</span>, {
  method: <span class="s">"POST"</span>,
  headers: {
    <span class="s">"Content-Type"</span>: <span class="s">"application/json"</span>,
    <span class="s">"X-API-Key"</span>: <span class="s">"tbx_your_key_here"</span>,
  },
  body: JSON.stringify({ url: shareUrl }),
});
<span class="k">const</span> data = <span class="k">await</span> res.json();
<span class="k">if</span> (data.ok) {
  data.files.<span class="k">forEach</span>((f) =&gt; console.log(f.filename, f.download_url));
}</pre>

      <h3 style="margin-top:44px">Error codes</h3>
      <div class="table-wrap" style="margin-top:14px">
        <table>
          <thead><tr><th>HTTP</th><th>Code</th><th>Meaning</th></tr></thead>
          <tbody>
            <tr><td><code>400</code></td><td><code>ERRNO_-12</code></td><td>The link is invalid or has expired</td></tr>
            <tr><td><code>400</code></td><td><code>PASSWORD_REQUIRED</code></td><td>Send the 4-character code in <code>pwd</code></td></tr>
            <tr><td><code>400</code></td><td><code>BAD_PASSWORD</code></td><td>The extraction code is wrong</td></tr>
            <tr><td><code>401</code></td><td><code>—</code></td><td>Missing or invalid <code>X-API-Key</code></td></tr>
            <tr><td><code>429</code></td><td><code>—</code></td><td>Quota or rate limit reached</td></tr>
            <tr><td><code>500</code></td><td><code>UPSTREAM</code></td><td>TeraBox did not respond — retry shortly</td></tr>
          </tbody>
        </table>
      </div>

      <div class="note">
        <b>About <code>download_url</code>.</b> TeraBox only hands out a direct CDN link to an authenticated
        session, so <code>download_url</code> is empty unless the server is configured with a TeraBox Open
        Platform token (<code>TERABOX_ACCESS_TOKEN</code>). The <code>stream_url</code> always works and points
        at an HLS playlist served by this site.
      </div>

      <div class="note warn">
        Use the API for material you have the right to download. The API grants no rights over the files it
        resolves, and abusive use will get the key revoked.
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'contact',
  file: 'contact.html',
  active: '/contact/',
  title: `Contact ${B.name} — Support & Feedback`,
  description: `Report a link that will not resolve, report a bug, or ask about the API. We read every message.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Contact</span>
      <h1>Tell us what <span class="gradient-text">broke</span></h1>
      <p class="lead">A link that will not resolve, a bug, or a domain we are missing — all of it helps.</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="grid grid-2" style="align-items:start">
        <div class="card">
          <h3>Email</h3>
          <p>The fastest route. We answer within one working day.</p>
          <p><a href="mailto:${B.supportEmail}" class="mono">${B.supportEmail}</a></p>
        </div>
        <div class="card">
          <h3>Telegram</h3>
          <p>Quick questions, and the fastest way to reach the operator.</p>
          <p><a href="https://t.me/${B.telegram.replace('@', '')}" class="mono">${B.telegram}</a></p>
        </div>
      </div>

      <h3 style="margin-top:40px">Before you write</h3>
      <div class="accordion" style="margin-top:16px">
        ${[
          ['A link says “invalid or expired”',
           'Open the same link in a normal browser tab. If TeraBox does not load it there, the share itself is gone or private — nothing the tool can fix.'],
          ['A link asks for an extraction code',
           'Only the person who shared the file can give you the 4-character code. We cannot bypass it, and we will not try.'],
          ['A download is slow',
           'Speed is limited by the TeraBox CDN and your own connection, not by the tool. Switching to a closer mirror sometimes helps.'],
          ['A video will not play',
           'The codec may not be supported by your browser. MKV in particular needs VLC on iOS. The download button still works.'],
        ]
          .map(([q, a]) => `<details><summary>${q}</summary><div class="answer"><p>${a}</p></div></details>`)
          .join('\n        ')}
      </div>

      <div class="note" style="margin-top:30px">
        Please do not send links to copyrighted material. We cannot help with that, and it puts the service
        at risk for everyone.
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'privacy-policy',
  file: 'privacy-policy.html',
  active: '/privacy-policy/',
  title: `Privacy Policy — ${B.name}`,
  description: `What ${B.name} collects, what it does not collect, and how to have your data removed.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Legal</span>
      <h1>Privacy policy</h1>
      <p class="lead">Last updated: ${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="prose">
        <p>
          ${B.name} (${B.domain}) is operated by ${B.legalName}. This policy explains what we collect when you
          use the downloader and the API, and what we deliberately do not.
        </p>

        <h2>What we collect</h2>
        <ul>
          <li><b>Nothing about the files you download.</b> We do not store, mirror, inspect or log file contents.</li>
          <li><b>No list of the links you paste.</b> A share URL is read into memory, resolved, and discarded.</li>
          <li><b>Anonymous counters.</b> We count requests per IP over a rolling ten-minute window purely to apply an anti-abuse limit. The counter is not tied to a file, a link or a person.</li>
          <li><b>API key records.</b> If you request a developer key we keep your email address, the key, a usage counter and the date it was created. We use this only to operate the API.</li>
        </li>

        <h2>What we do not collect</h2>
        <ul>
          <li>No TeraBox account, username or password — we never ask for one.</li>
          <li>No IP address stored alongside a download history.</li>
          <li>No advertising or analytics trackers, and no third-party tracking scripts.</li>
        </ul>

        <h2>Cookies</h2>
        <p>
          Our site does not set tracking cookies. When you resolve a link, the server temporarily holds a
          short-lived TeraBox session cookie in memory for the duration of the request so it can read the share.
          It is never written to disk and never shared with anyone.
        </p>

        <h2>Third parties</h2>
        <p>
          Resolving a link necessarily contacts TeraBox, so TeraBox receives the request and can apply its own
          privacy policy. We never send your email address, IP address or any identifier to TeraBox beyond what
          is technically required to perform the lookup. File bytes travel directly between TeraBox's servers and
          your device.
        </p>

        <h2>Data retention</h2>
        <p>
          Request counters expire within ten minutes. API key records are kept until you ask us to remove them.
          We do not keep logs of which links were resolved.
        </p>

        <h2>Your rights</h2>
        <p>
          If you have requested an API key, you can ask us to delete it and your email address at any time by
          writing to <a href="mailto:${B.supportEmail}">${B.supportEmail}</a>. We will remove the record within
          seven days.
        </p>

        <h2>Children</h2>
        <p>
          This service is not directed at children under 13 and we do not knowingly collect personal information
          from them.
        </p>

        <h2>Changes</h2>
        <p>
          If this policy changes materially we will update the date at the top of this page. Continued use of the
          service after a change means you accept the updated policy.
        </p>

        <h2>Contact</h2>
        <p>
          ${B.legalName} · <a href="mailto:${B.supportEmail}">${B.supportEmail}</a> · Jurisdiction: ${B.jurisdiction}
        </p>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'terms',
  file: 'terms.html',
  active: '/terms/',
  title: `Terms of Service — ${B.name}`,
  description: `The terms that govern the use of ${B.name}, including acceptable use and the limits of what the service provides.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Legal</span>
      <h1>Terms of service</h1>
      <p class="lead">Last updated: ${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="prose">
        <h2>1. The service</h2>
        <p>
          ${B.name} is a free tool that reads a public TeraBox share link you provide and returns a list of the
          files inside it together with direct download and streaming addresses for those files. We do not host
          any file, and we do not grant you any right to any file.
        </p>

        <h2>2. Acceptable use</h2>
        <p>You agree to use ${B.name} only for material you own or have permission to download. Specifically, you agree not to:</p>
        <ul>
          <li>Use the service to obtain or redistribute copyrighted material without the rights holder’s permission.</li>
          <li>Circumvent access controls, private shares, or a share’s extraction code.</li>
          <li>Abuse, overload, scrape or resell the service, or attempt to bypass its rate limits.</li>
          <li>Use the service in a way that breaks applicable law.</li>
        </ul>
        <p>
          We may block any IP address or API key that violates this section, without notice.
        </p>

        <h2>3. No warranty</h2>
        <p>
          The service is provided “as is”, without warranties of any kind. TeraBox changes its own systems
          without notice, and a link that works today may stop working tomorrow. We do not guarantee that any
          link will resolve, that any file will download, or that the service will be available at any moment.
        </p>

        <h2>4. Limitation of liability</h2>
        <p>
          To the maximum extent permitted by law, ${B.legalName} is not liable for any indirect, incidental or
          consequential damages arising from your use of the service, including any loss of data, profit or
          goodwill, or any claim that content you downloaded through the service infringed someone’s rights.
        </p>

        <h2>5. Intellectual property</h2>
        <p>
          The ${B.name} name and site content belong to ${B.legalName}. TeraBox and all related names, logos and
          trademarks belong to their respective owners. We are not affiliated with, endorsed by, or sponsored by
          TeraBox or Flextech Inc.
        </p>

        <h2>6. Changes</h2>
        <p>
          We may update these terms at any time. The version published on this page at the time you use the
          service is the version that applies to you.
        </p>

        <h2>7. Contact</h2>
        <p><a href="mailto:${B.supportEmail}">${B.supportEmail}</a> · Jurisdiction: ${B.jurisdiction}</p>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: 'blog/how-to-download-from-terabox',
  file: 'blog/how-to-download-from-terabox.html',
  active: '',
  title: `How to Download from TeraBox (${new Date().getFullYear()}) — Complete Guide | ${B.name}`,
  description: `A complete, step-by-step guide to downloading files and videos from TeraBox on any device, with the common problems and their fixes.`,
  body: `
  <section class="hero" style="padding-bottom:10px">
    <div class="wrap center">
      <span class="badge">Guide</span>
      <h1>How to download from TeraBox</h1>
      <p class="lead">The complete method — plus the four problems people hit, and how to fix each one.</p>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="prose">
        <h2>The quick version</h2>
        <ol>
          <li>Copy your TeraBox share link.</li>
          <li>Paste it into the box at the top of this page.</li>
          <li>Click <b>Get direct link</b>, then download or play the file.</li>
        </ol>

        <h2>Step 1 — copy the link</h2>
        <p>
          Open the file or folder in TeraBox, tap <b>Share</b> and copy the link. It usually looks like
          <code class="mono">https://www.terabox.com/s/1AbCdEf…</code>. If it looks like
          <code class="mono">…/sharing/link?surl=…</code> instead, that is fine too — both shapes work.
        </p>

        <h2>Step 2 — paste it into ${B.name}</h2>
        <p>
          Put the link in the input box and press the button. The tool contacts TeraBox, reads the share and
          lists every file inside it with names, sizes and direct links. If the share is protected by a
          4-character extraction code, a field will appear — type the code the sender gave you and press Unlock.
        </p>

        <h2>Step 3 — download or stream</h2>
        <p>
          Each row in the result list has its own download button. For video files there is also a play button,
          which opens the file in the built-in player on the page — handy for checking whether a video is what
          you expected before pulling a large file down.
        </p>

        <h2>Step 4 — on your phone</h2>
        <ul>
          <li><b>Android:</b> open the link in Chrome, paste it into the box, tap <b>Get direct link</b>, then the download arrow. The file lands in your Downloads folder.</li>
          <li><b>iPhone:</b> same flow in Safari. MP4 and MOV play natively; MKV needs VLC.</li>
        </ul>

        <h2>Common problems</h2>

        <h3>“Invalid or expired”</h3>
        <p>
          The share was deleted, set to expire, or made private. Open the original link in a normal browser tab
          — if TeraBox will not load it there either, the file is genuinely gone.
        </p>

        <h3>“This link is protected by an extraction code”</h3>
        <p>
          The sender set a 4-character code on the share. Only they can give it to you. We cannot and will not
          bypass it.
        </p>

        <h3>The download starts but stalls</h3>
        <p>
          TeraBox throttles free accounts on some mirrors. If the share was created on a mirror that is far from
          you, the transfer will be slow no matter which tool you use. Retrying often picks a different CDN node.
        </p>

        <h3>The video will not play in the page</h3>
        <p>
          The codec is not supported by your browser — most often MKV, or HEVC (H.265) inside an MP4 container.
          The download button still works, and the file plays fine in VLC or a desktop player.
        </p>

        <h2>Legal note</h2>
        <div class="note warn">
          Only download files you own or have permission to download. The tool does not grant rights over
          anything it resolves, and downloading copyrighted material without permission is both unlawful and
          prohibited by our terms of service.
        </div>
      </div>
    </div>
  </section>`,
});

PAGES.push({
  slug: '404',
  file: '404.html',
  active: '',
  title: `Page not found — ${B.name}`,
  description: 'The page you were looking for does not exist.',
  body: `
  <section class="hero" style="padding:90px 0">
    <div class="wrap center">
      <h1 style="font-size:clamp(3rem,10vw,6rem)">404</h1>
      <p class="lead">That page does not exist — but the downloader does.</p>
      <a class="btn btn-lg" href="/">Go to the downloader</a>
    </div>
  </section>`,
});

/* ------------------------------------------------------------------ */
/* write                                                               */
/* ------------------------------------------------------------------ */

function write(relPath, html) {
  const full = path.join(OUT, relPath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, html, 'utf8');
  console.log('  ✓', relPath);
}

console.log('building pages…');
for (const page of PAGES) {
  const html = layout({
    slug: page.slug,
    title: page.title,
    description: page.description,
    body: page.body,
    active: page.active,
  });
  write(page.file, html);
}
console.log('done.');
