# TeraBeam — free TeraBox downloader & player

A complete, production-ready website that turns a public TeraBox share link into a
file list and plays videos straight in the browser.

Built to be the same shape as the service you pointed me at (`teraboxdl.site`):
paste a link → see every file → download or stream — but re-branded, re-written
from scratch, and with all of the original copy, layout and branding replaced.

```
Node.js ≥ 18 · zero npm dependencies · no build step
```

---

## 1. What actually works

| Feature | Status | Needs credentials? |
|---|---|---|
| Parse any TeraBox link (all domains, both formats) | ✅ working | no |
| Read the share → full file list (name, size, type, thumbnail) | ✅ working | no |
| Shared-folder contents (sub-folder listing) | ✅ working | no |
| Extraction-code (password) detection + unlock | ✅ working | no |
| Stream video in the browser (HLS, with seek bar) | ✅ working | no |
| One-click download of the **original** file | ⚠️ needs a TeraBox token | yes |

### Why the download button needs a token

TeraBox changed its policy: **the public web app no longer hands out a direct
CDN link to anonymous visitors.** Asking their own API for one returns
`errno 2` ("sign in required") — that is exactly what the browser does when you
press *Download* on a share page without an account.

There are two supported ways to enable one-click downloads on your server:

1. **`TERABOX_ACCESS_TOKEN` (recommended)** — a token from the official
   [TeraBox Open Platform](https://www.terabox.com/integrations/docs). This is
   the documented, ToS-friendly route for building a product like this. Register
   an app there and paste the token into your environment.
2. **`TERABOX_COOKIE`** — a signed-in TeraBox session cookie (`ndus=…`). It
   works, but you are lending the service your personal session, so use it only
   if you understand the trade-offs.

Without either, the site still works: it lists every file and streams video.
The download button falls back to opening the official TeraBox share page.

---

## 2. Run it

```bash
cd terabeam
node server/index.js          # → http://localhost:3000
```

That is the whole setup — there is no `npm install` because there are no
dependencies.

| Env var | Default | Meaning |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `SITE_URL` | `https://terabeam.com` | canonical URL (used in links, sitemap, OG tags) |
| `APP_SECRET` | *(change me)* | encrypts the download/stream tokens — **change this in production** |
| `TERABOX_ACCESS_TOKEN` | – | TeraBox Open Platform token (enables direct downloads) |
| `TERABOX_COOKIE` | – | signed-in TeraBox session cookie (enables direct downloads) |
| `DOWNLOAD_MODE` | `proxy` | `proxy` streams bytes through your server |
| `RATE_LIMIT` | `60` | requests per IP per 10 minutes |
| `AUTO_APPROVE_KEYS` | `true` | auto-approve API key requests |
| `DATA_DIR` | `./data` | where API keys are stored |

Copy `.env.example` to `.env` and adjust, or set the variables in your host's
dashboard. (The server reads plain environment variables — put them in your
process manager, systemd unit, Docker `--env-file`, or a `.env` loader of your
choice.)

---

## 3. Rebrand it (one file)

Everything about the brand lives in **`site.config.js`**:

```js
brand: {
  name: 'TeraBeam',                  // ← your product name
  domain: 'terabeam.com',            // ← your domain
  url: process.env.SITE_URL || 'https://terabeam.com',
  tagline: 'Paste. Fetch. Done.',
  description: '…',
  supportEmail: 'support@terabeam.com',
  telegram: '@terabeam',
  ...
}
```

Then:

```bash
node tools/build-pages.js      # regenerates every HTML page
```

Colours live at the top of `public/assets/style.css` (the `:root` variables) and
the logo is `public/assets/logo.svg`.

---

## 4. Pages

| Path | Page |
|---|---|
| `/` | downloader + how it works + FAQ preview |
| `/supported-domains/` | every TeraBox domain and both link formats |
| `/faq/` | full FAQ |
| `/api/` | developer API docs + key request form |
| `/about/` | about us |
| `/contact/` | contact + troubleshooting |
| `/blog/how-to-download-from-terabox/` | long-form guide |
| `/privacy-policy/` | privacy policy |
| `/terms/` | terms of service |
| `/404.html` | not found |

---

## 5. HTTP API

### `POST /api/resolve`

```bash
curl -X POST http://localhost:3000/api/resolve \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://www.terabox.com/s/1AbCdEf…"}'
```

```json
{
  "ok": true,
  "ms": 1180,
  "canDownload": false,
  "share": { "owner": "an***7", "country": "IN", "fileCount": 1, "totalSizeText": "954 MB" },
  "files": [
    {
      "name": "clip.mkv",
      "sizeText": "954 MB",
      "category": "video",
      "streamUrl": "/api/stream?t=…",
      "downloadUrl": "",
      "openUrl": "https://www.terabox.com/s/1AbCdEf…"
    }
  ]
}
```

Body fields: `url` (required), `pwd` (4-character extraction code), `dir`
(sub-folder inside a shared folder).

### `POST /v1/api` (developer API, needs `X-API-Key`)

```bash
curl -X POST https://your-domain.com/v1/api \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: tbx_…' \
  -d '{"url":"https://www.terabox.com/s/1AbCdEf…"}'
```

Keys are requested from the `/api/` page and stored in `data/keys.json`.

### Other endpoints

| Endpoint | Purpose |
|---|---|
| `GET /api/stream?t=…` | HLS playlist, segment URLs rewritten to our proxy |
| `GET /api/segment?t=…` | segment proxy (supports `Range`) |
| `GET /api/file?t=…&mode=download` | direct file download (needs a TeraBox token) |
| `GET /healthz` | health check + whether downloads are enabled |
| `GET /robots.txt`, `/sitemap.xml` | generated on the fly |

---

## 6. Deploy

### Render / Railway / Fly.io (Docker)

```bash
docker build -t terabeam .
docker run -p 3000:3000 -e APP_SECRET="$(openssl rand -hex 32)" terabeam
```

`render.yaml` is included — push the repo and Render picks it up.

### Any Node host

```bash
git clone <your-repo> && cd terabeam
node server/index.js
```

Put it behind nginx/Caddy for TLS, and set `SITE_URL`, `APP_SECRET` and
`TERABOX_ACCESS_TOKEN`.

### Static-only hosting

The HTML/CSS/JS in `public/` can go on any static host, but the resolver needs
a server — the browser cannot call TeraBox directly (CORS), so `/api/resolve`
must live on a Node server.

---

## 7. How the resolver works

Implemented from TeraBox's own web-share flow:

```
GET  /sharing/link?surl=CODE     → session cookies + window.jsToken
GET  /api/shorturlinfo           → shareid, uk, sign, timestamp, file list
POST /share/verify                → only for extraction-code protected shares
GET  /share/list                  → contents of a sub-folder
GET  /share/streaming             → HLS playlist (signed with HMAC-SHA1)
GET  /share/download              → direct CDN link (needs a TeraBox token)
```

Details worth knowing:

* A `browserid` cookie is required — the resolver grabs one from the share page
  automatically, and reuses it for the life of the request.
* The streaming URL is signed with `HMAC-SHA1(clienttype + channel + browserid
  + timestamp, salt)`, exactly like the browser does.
* Mirrors are tried in parallel with a 4-way concurrency cap, so a dead mirror
  never slows a request down. A mirror that fails is put on a 90-second
  cooldown.
* Every errno is translated into a sentence a human can act on.

---

## 8. Test it

```bash
node tools/test-site.js                       # end-to-end against a live share
node tools/test-site.js "https://…/s/1XXXX"   # a specific link
```

The script resolves a link, fetches the playlist, downloads the first segment
and verifies it is a valid MPEG-TS stream.

---

## 9. Legal & ethics

* TeraBeam is an independent tool. It is **not** affiliated with, endorsed by,
  or sponsored by TeraBox or Flextech Inc.
* Nothing is hosted, stored, mirrored or inspected. Links are processed in
  memory and discarded.
* Use it only for files you own or have permission to download. The
  [terms of service](/terms/) and [privacy policy](/privacy-policy/) pages are
  part of the site and are written to be edited to your own business details.
* TeraBox, Terabox and all related logos are trademarks of their owners.

MIT licensed.
